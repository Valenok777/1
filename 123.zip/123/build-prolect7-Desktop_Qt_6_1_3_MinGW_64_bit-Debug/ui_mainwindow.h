/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.1.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QTableWidget *tableWidget;
    QSpinBox *spinBox_Row_valueChange;
    QPushButton *pushButton_Random;
    QLabel *label_namber_row;
    QPushButton *pushButton_MIN_MAX_MEAN;
    QLabel *label_MIN_result;
    QLabel *label_MAX_result;
    QLabel *label_MEAN_result;
    QLabel *label_MIN_MAX_MEAN;
    QLabel *label_MIN;
    QLabel *label_MAX;
    QLabel *label_MEAN;
    QPushButton *pushButton_bubble;
    QLabel *label_sorting;
    QPushButton *pushButton_gnome;
    QPushButton *pushButton_comb;
    QPushButton *pushButton_quick;
    QPushButton *pushButton;
    QPushButton *pushButton_monkey;
    QLineEdit *lineEdit;
    QLabel *label_search;
    QTableWidget *tableWidget_2;
    QFrame *line;
    QPushButton *pushButton_search;
    QPushButton *pushButton_duplicates;
    QFrame *line_2;
    QFrame *line_3;
    QLabel *label_filling_method;
    QFrame *line_4;
    QPushButton *pushButton_copletition;
    QLineEdit *lineEdit_completion;
    QLabel *label_completion;
    QLabel *label_random;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1004, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        tableWidget = new QTableWidget(centralwidget);
        if (tableWidget->columnCount() < 1)
            tableWidget->setColumnCount(1);
        if (tableWidget->rowCount() < 5)
            tableWidget->setRowCount(5);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(20, 10, 171, 531));
        tableWidget->viewport()->setProperty("cursor", QVariant(QCursor(Qt::ArrowCursor)));
        tableWidget->setMouseTracking(false);
        tableWidget->setFocusPolicy(Qt::StrongFocus);
        tableWidget->setRowCount(5);
        tableWidget->setColumnCount(1);
        spinBox_Row_valueChange = new QSpinBox(centralwidget);
        spinBox_Row_valueChange->setObjectName(QString::fromUtf8("spinBox_Row_valueChange"));
        spinBox_Row_valueChange->setGeometry(QRect(330, 30, 121, 25));
        spinBox_Row_valueChange->setMinimum(1);
        spinBox_Row_valueChange->setMaximum(20);
        spinBox_Row_valueChange->setValue(5);
        pushButton_Random = new QPushButton(centralwidget);
        pushButton_Random->setObjectName(QString::fromUtf8("pushButton_Random"));
        pushButton_Random->setGeometry(QRect(520, 100, 81, 21));
        label_namber_row = new QLabel(centralwidget);
        label_namber_row->setObjectName(QString::fromUtf8("label_namber_row"));
        label_namber_row->setGeometry(QRect(210, 30, 121, 21));
        pushButton_MIN_MAX_MEAN = new QPushButton(centralwidget);
        pushButton_MIN_MAX_MEAN->setObjectName(QString::fromUtf8("pushButton_MIN_MAX_MEAN"));
        pushButton_MIN_MAX_MEAN->setGeometry(QRect(520, 220, 71, 51));
        pushButton_MIN_MAX_MEAN->setAutoRepeat(false);
        pushButton_MIN_MAX_MEAN->setAutoExclusive(false);
        label_MIN_result = new QLabel(centralwidget);
        label_MIN_result->setObjectName(QString::fromUtf8("label_MIN_result"));
        label_MIN_result->setGeometry(QRect(360, 220, 91, 31));
        label_MAX_result = new QLabel(centralwidget);
        label_MAX_result->setObjectName(QString::fromUtf8("label_MAX_result"));
        label_MAX_result->setGeometry(QRect(360, 280, 91, 31));
        label_MEAN_result = new QLabel(centralwidget);
        label_MEAN_result->setObjectName(QString::fromUtf8("label_MEAN_result"));
        label_MEAN_result->setGeometry(QRect(360, 250, 91, 31));
        label_MIN_MAX_MEAN = new QLabel(centralwidget);
        label_MIN_MAX_MEAN->setObjectName(QString::fromUtf8("label_MIN_MAX_MEAN"));
        label_MIN_MAX_MEAN->setGeometry(QRect(210, 190, 391, 31));
        label_MIN_MAX_MEAN->setTextFormat(Qt::AutoText);
        label_MIN_MAX_MEAN->setScaledContents(false);
        label_MIN_MAX_MEAN->setWordWrap(true);
        label_MIN = new QLabel(centralwidget);
        label_MIN->setObjectName(QString::fromUtf8("label_MIN"));
        label_MIN->setGeometry(QRect(250, 220, 91, 31));
        label_MAX = new QLabel(centralwidget);
        label_MAX->setObjectName(QString::fromUtf8("label_MAX"));
        label_MAX->setGeometry(QRect(250, 280, 91, 31));
        label_MEAN = new QLabel(centralwidget);
        label_MEAN->setObjectName(QString::fromUtf8("label_MEAN"));
        label_MEAN->setGeometry(QRect(250, 250, 91, 31));
        pushButton_bubble = new QPushButton(centralwidget);
        pushButton_bubble->setObjectName(QString::fromUtf8("pushButton_bubble"));
        pushButton_bubble->setGeometry(QRect(210, 380, 80, 31));
        label_sorting = new QLabel(centralwidget);
        label_sorting->setObjectName(QString::fromUtf8("label_sorting"));
        label_sorting->setGeometry(QRect(210, 350, 141, 21));
        pushButton_gnome = new QPushButton(centralwidget);
        pushButton_gnome->setObjectName(QString::fromUtf8("pushButton_gnome"));
        pushButton_gnome->setGeometry(QRect(310, 380, 80, 31));
        pushButton_comb = new QPushButton(centralwidget);
        pushButton_comb->setObjectName(QString::fromUtf8("pushButton_comb"));
        pushButton_comb->setGeometry(QRect(410, 380, 80, 31));
        pushButton_quick = new QPushButton(centralwidget);
        pushButton_quick->setObjectName(QString::fromUtf8("pushButton_quick"));
        pushButton_quick->setGeometry(QRect(210, 430, 80, 31));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(210, 490, 80, 51));
        pushButton_monkey = new QPushButton(centralwidget);
        pushButton_monkey->setObjectName(QString::fromUtf8("pushButton_monkey"));
        pushButton_monkey->setGeometry(QRect(310, 430, 80, 31));
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(812, 30, 81, 20));
        label_search = new QLabel(centralwidget);
        label_search->setObjectName(QString::fromUtf8("label_search"));
        label_search->setGeometry(QRect(640, 30, 171, 21));
        tableWidget_2 = new QTableWidget(centralwidget);
        if (tableWidget_2->columnCount() < 1)
            tableWidget_2->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(0, __qtablewidgetitem);
        tableWidget_2->setObjectName(QString::fromUtf8("tableWidget_2"));
        tableWidget_2->setGeometry(QRect(640, 60, 161, 481));
        tableWidget_2->setRowCount(0);
        tableWidget_2->setColumnCount(1);
        line = new QFrame(centralwidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(610, 0, 20, 551));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        pushButton_search = new QPushButton(centralwidget);
        pushButton_search->setObjectName(QString::fromUtf8("pushButton_search"));
        pushButton_search->setGeometry(QRect(900, 30, 81, 21));
        pushButton_duplicates = new QPushButton(centralwidget);
        pushButton_duplicates->setObjectName(QString::fromUtf8("pushButton_duplicates"));
        pushButton_duplicates->setGeometry(QRect(820, 70, 151, 61));
        line_2 = new QFrame(centralwidget);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(200, 160, 411, 20));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(centralwidget);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setGeometry(QRect(200, 470, 411, 20));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);
        label_filling_method = new QLabel(centralwidget);
        label_filling_method->setObjectName(QString::fromUtf8("label_filling_method"));
        label_filling_method->setGeometry(QRect(210, 70, 231, 21));
        line_4 = new QFrame(centralwidget);
        line_4->setObjectName(QString::fromUtf8("line_4"));
        line_4->setGeometry(QRect(200, 320, 411, 20));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);
        pushButton_copletition = new QPushButton(centralwidget);
        pushButton_copletition->setObjectName(QString::fromUtf8("pushButton_copletition"));
        pushButton_copletition->setGeometry(QRect(520, 130, 80, 21));
        lineEdit_completion = new QLineEdit(centralwidget);
        lineEdit_completion->setObjectName(QString::fromUtf8("lineEdit_completion"));
        lineEdit_completion->setGeometry(QRect(420, 130, 91, 21));
        label_completion = new QLabel(centralwidget);
        label_completion->setObjectName(QString::fromUtf8("label_completion"));
        label_completion->setGeometry(QRect(210, 130, 211, 21));
        label_random = new QLabel(centralwidget);
        label_random->setObjectName(QString::fromUtf8("label_random"));
        label_random->setGeometry(QRect(210, 100, 291, 21));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1004, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);
        QWidget::setTabOrder(tableWidget, spinBox_Row_valueChange);
        QWidget::setTabOrder(spinBox_Row_valueChange, pushButton_Random);
        QWidget::setTabOrder(pushButton_Random, pushButton_MIN_MAX_MEAN);
        QWidget::setTabOrder(pushButton_MIN_MAX_MEAN, pushButton_bubble);
        QWidget::setTabOrder(pushButton_bubble, pushButton_gnome);
        QWidget::setTabOrder(pushButton_gnome, pushButton_comb);
        QWidget::setTabOrder(pushButton_comb, pushButton_quick);
        QWidget::setTabOrder(pushButton_quick, pushButton_monkey);
        QWidget::setTabOrder(pushButton_monkey, pushButton);
        QWidget::setTabOrder(pushButton, lineEdit);
        QWidget::setTabOrder(lineEdit, pushButton_search);
        QWidget::setTabOrder(pushButton_search, tableWidget_2);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton_Random->setText(QCoreApplication::translate("MainWindow", "\320\240\320\260\320\275\320\264\320\276\320\274", nullptr));
        label_namber_row->setText(QCoreApplication::translate("MainWindow", "\320\232\320\276\320\273\320\270\321\207\320\265\321\201\321\202\320\262\320\276 \321\207\320\270\321\201\320\265\320\273", nullptr));
        pushButton_MIN_MAX_MEAN->setText(QCoreApplication::translate("MainWindow", "\320\237\321\203\321\201\320\272", nullptr));
        label_MIN_result->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        label_MAX_result->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        label_MEAN_result->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        label_MIN_MAX_MEAN->setText(QCoreApplication::translate("MainWindow", "\320\222\321\213\321\207\320\270\321\201\320\273\320\265\320\275\320\270\321\217 \320\274\320\270\320\275\320\270\320\274\320\260\320\273\321\214\320\275\320\276\320\263\320\276, \320\274\320\260\320\272\321\201\320\270\320\274\320\260\320\273\321\214\320\275\320\276\320\263\320\276 \320\270 \321\201\321\200\320\265\320\264\320\275\320\265\320\263\320\276 \320\267\320\275\320\260\321\207\320\265\320\275\320\270\320\271", nullptr));
        label_MIN->setText(QCoreApplication::translate("MainWindow", "\320\234\320\270\320\275\320\270\320\274\320\260\320\273\321\214\320\275\320\276\320\265", nullptr));
        label_MAX->setText(QCoreApplication::translate("MainWindow", "\320\234\320\260\320\272\321\201\320\270\320\274\320\260\320\273\321\214\320\275\320\276\320\265", nullptr));
        label_MEAN->setText(QCoreApplication::translate("MainWindow", "\320\241\321\200\320\265\320\264\320\275\320\265\320\265", nullptr));
        pushButton_bubble->setText(QCoreApplication::translate("MainWindow", "\320\237\321\203\320\267\321\213\321\200\321\214\320\272\320\276\320\274", nullptr));
        label_sorting->setText(QCoreApplication::translate("MainWindow", "\320\241\320\276\321\200\321\202\320\270\321\200\320\276\320\262\320\272\320\270:", nullptr));
        pushButton_gnome->setText(QCoreApplication::translate("MainWindow", "\320\223\320\275\320\276\320\274\320\270\320\272\320\276\320\274", nullptr));
        pushButton_comb->setText(QCoreApplication::translate("MainWindow", "\320\240\320\260\321\201\321\207\320\265\321\201\321\202\320\272\320\260", nullptr));
        pushButton_quick->setText(QCoreApplication::translate("MainWindow", "\320\221\321\213\321\201\321\202\321\200\320\260\321\217", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "\320\236\321\207\320\270\321\201\321\202\320\272\320\260", nullptr));
        pushButton_monkey->setText(QCoreApplication::translate("MainWindow", "\320\236\320\261\320\265\320\267\321\214\321\217\320\275\321\214\321\217", nullptr));
        label_search->setText(QCoreApplication::translate("MainWindow", "\320\237\320\276\320\270\321\201\320\272 \320\267\320\275\320\260\321\207\320\265\320\275\320\270\321\217 \320\262 \321\202\320\260\320\261\320\273\320\270\321\206\320\265:", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget_2->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "\320\235\320\276\320\274\320\265\321\200 \321\201\321\202\321\200\320\276\320\272\320\270", nullptr));
        pushButton_search->setText(QCoreApplication::translate("MainWindow", "\320\237\320\276\320\270\321\201\320\272", nullptr));
        pushButton_duplicates->setText(QCoreApplication::translate("MainWindow", "\320\243\320\264\320\260\320\273\320\265\320\275\320\270\320\265 \320\264\321\203\320\261\320\273\320\270\320\272\320\260\321\202\320\276\320\262", nullptr));
        label_filling_method->setText(QCoreApplication::translate("MainWindow", "\320\241\320\277\320\276\321\201\320\276\320\261\321\213 \320\267\320\260\320\277\320\276\320\273\320\275\320\265\320\275\320\270\321\217 \320\274\320\260\321\201\321\201\320\270\320\262\320\260:", nullptr));
        pushButton_copletition->setText(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\277\320\276\320\273\320\275\320\270\321\202\321\214", nullptr));
        label_completion->setText(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\277\320\276\320\273\320\275\320\270\321\202\321\214 \321\202\320\260\320\261\320\273\320\270\321\206\321\203 \320\276\320\264\320\275\320\270\320\274 \321\207\320\270\321\201\320\273\320\276\320\274:", nullptr));
        label_random->setText(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\277\320\276\320\273\320\275\320\270\321\202\321\214 \321\202\320\260\320\261\320\273\320\270\321\206\321\203 \321\200\320\260\320\275\320\264\320\276\320\274\320\275\321\213\320\274\320\270 \320\267\320\275\320\260\321\207\320\265\320\275\320\270\321\217\320\274\320\270:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
