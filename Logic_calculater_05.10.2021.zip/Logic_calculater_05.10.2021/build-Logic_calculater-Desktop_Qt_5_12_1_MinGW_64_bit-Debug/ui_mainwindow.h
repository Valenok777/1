/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QComboBox *comboBox_op1;
    QComboBox *comboBox_oper;
    QComboBox *comboBox_op2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        comboBox_op1 = new QComboBox(centralwidget);
        comboBox_op1->addItem(QString());
        comboBox_op1->addItem(QString());
        comboBox_op1->setObjectName(QString::fromUtf8("comboBox_op1"));
        comboBox_op1->setGeometry(QRect(70, 130, 161, 41));
        comboBox_oper = new QComboBox(centralwidget);
        comboBox_oper->addItem(QString());
        comboBox_oper->addItem(QString());
        comboBox_oper->addItem(QString());
        comboBox_oper->addItem(QString());
        comboBox_oper->addItem(QString());
        comboBox_oper->addItem(QString());
        comboBox_oper->setObjectName(QString::fromUtf8("comboBox_oper"));
        comboBox_oper->setGeometry(QRect(280, 130, 241, 71));
        comboBox_op2 = new QComboBox(centralwidget);
        comboBox_op2->addItem(QString());
        comboBox_op2->addItem(QString());
        comboBox_op2->setObjectName(QString::fromUtf8("comboBox_op2"));
        comboBox_op2->setGeometry(QRect(570, 130, 161, 41));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        comboBox_op1->setItemText(0, QApplication::translate("MainWindow", "false", nullptr));
        comboBox_op1->setItemText(1, QApplication::translate("MainWindow", "true", nullptr));

        comboBox_oper->setItemText(0, QApplication::translate("MainWindow", "\320\224\320\270\320\267\321\214\321\216\320\275\320\272\321\206\320\270\321\217", nullptr));
        comboBox_oper->setItemText(1, QApplication::translate("MainWindow", "\320\232\320\276\320\275\321\214\321\216\320\272\321\206\320\270\321\217", nullptr));
        comboBox_oper->setItemText(2, QApplication::translate("MainWindow", "\320\230\320\275\320\262\320\265\321\200\321\201\320\270\321\217", nullptr));
        comboBox_oper->setItemText(3, QApplication::translate("MainWindow", "\320\241\320\273\320\265\320\264\320\276\320\262\320\260\320\275\320\270\320\265", nullptr));
        comboBox_oper->setItemText(4, QApplication::translate("MainWindow", "\320\255\320\272\320\262\320\270\320\262\320\260\320\273\320\265\320\275\321\202\320\275\320\276\321\201\321\202\321\214", nullptr));
        comboBox_oper->setItemText(5, QApplication::translate("MainWindow", "\320\241\321\202\321\200\320\276\320\263\320\260\321\217 \320\264\320\270\320\267\321\214\321\216\320\275\320\272\321\206\320\270\321\217", nullptr));

        comboBox_op2->setItemText(0, QApplication::translate("MainWindow", "false", nullptr));
        comboBox_op2->setItemText(1, QApplication::translate("MainWindow", "true", nullptr));

    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
