/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.1.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../poisk9/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.1.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    const uint offsetsAndSize[52];
    char stringdata0[436];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 10), // "MainWindow"
QT_MOC_LITERAL(11, 26), // "on_tableWidget_cellChanged"
QT_MOC_LITERAL(38, 0), // ""
QT_MOC_LITERAL(39, 3), // "row"
QT_MOC_LITERAL(43, 6), // "column"
QT_MOC_LITERAL(50, 27), // "on_spinBox_row_valueChanged"
QT_MOC_LITERAL(78, 4), // "arg1"
QT_MOC_LITERAL(83, 27), // "on_pushButton_clear_clicked"
QT_MOC_LITERAL(111, 26), // "on_pushButton_rand_clicked"
QT_MOC_LITERAL(138, 25), // "on_pushButton_min_clicked"
QT_MOC_LITERAL(164, 29), // "on_pushButton_srednee_clicked"
QT_MOC_LITERAL(194, 10), // "quick_sort"
QT_MOC_LITERAL(205, 7), // "double*"
QT_MOC_LITERAL(213, 10), // "mas_table1"
QT_MOC_LITERAL(224, 9), // "rascheska"
QT_MOC_LITERAL(234, 5), // "buble"
QT_MOC_LITERAL(240, 4), // "gnom"
QT_MOC_LITERAL(245, 6), // "monkey"
QT_MOC_LITERAL(252, 6), // "sorted"
QT_MOC_LITERAL(259, 7), // "err_str"
QT_MOC_LITERAL(267, 26), // "on_pushButton_sort_clicked"
QT_MOC_LITERAL(294, 25), // "on_pushButton_max_clicked"
QT_MOC_LITERAL(320, 27), // "on_pushButton_poisk_clicked"
QT_MOC_LITERAL(348, 29), // "on_lineEdit_poisk_textChanged"
QT_MOC_LITERAL(378, 28), // "on_pushButton_addrow_clicked"
QT_MOC_LITERAL(407, 28) // "on_pushButton_delrow_clicked"

    },
    "MainWindow\0on_tableWidget_cellChanged\0"
    "\0row\0column\0on_spinBox_row_valueChanged\0"
    "arg1\0on_pushButton_clear_clicked\0"
    "on_pushButton_rand_clicked\0"
    "on_pushButton_min_clicked\0"
    "on_pushButton_srednee_clicked\0quick_sort\0"
    "double*\0mas_table1\0rascheska\0buble\0"
    "gnom\0monkey\0sorted\0err_str\0"
    "on_pushButton_sort_clicked\0"
    "on_pushButton_max_clicked\0"
    "on_pushButton_poisk_clicked\0"
    "on_lineEdit_poisk_textChanged\0"
    "on_pushButton_addrow_clicked\0"
    "on_pushButton_delrow_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       9,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,  128,    2, 0x08,    0 /* Private */,
       5,    1,  133,    2, 0x08,    3 /* Private */,
       7,    0,  136,    2, 0x08,    5 /* Private */,
       8,    0,  137,    2, 0x08,    6 /* Private */,
       9,    0,  138,    2, 0x08,    7 /* Private */,
      10,    0,  139,    2, 0x08,    8 /* Private */,
      11,    2,  140,    2, 0x08,    9 /* Private */,
      14,    1,  145,    2, 0x08,   12 /* Private */,
      15,    1,  148,    2, 0x08,   14 /* Private */,
      16,    1,  151,    2, 0x08,   16 /* Private */,
      17,    1,  154,    2, 0x08,   18 /* Private */,
      18,    2,  157,    2, 0x08,   20 /* Private */,
      19,    0,  162,    2, 0x08,   23 /* Private */,
      20,    0,  163,    2, 0x08,   24 /* Private */,
      21,    0,  164,    2, 0x08,   25 /* Private */,
      22,    0,  165,    2, 0x08,   26 /* Private */,
      23,    0,  166,    2, 0x08,   27 /* Private */,
      24,    0,  167,    2, 0x08,   28 /* Private */,
      25,    0,  168,    2, 0x08,   29 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    3,    4,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12, QMetaType::Int,   13,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Bool, 0x80000000 | 12, QMetaType::Int,   13,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_tableWidget_cellChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 1: _t->on_spinBox_row_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->on_pushButton_clear_clicked(); break;
        case 3: _t->on_pushButton_rand_clicked(); break;
        case 4: _t->on_pushButton_min_clicked(); break;
        case 5: _t->on_pushButton_srednee_clicked(); break;
        case 6: _t->quick_sort((*reinterpret_cast< double*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 7: _t->rascheska((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->buble((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->gnom((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->monkey((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: { bool _r = _t->sorted((*reinterpret_cast< double*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 12: _t->err_str(); break;
        case 13: _t->on_pushButton_sort_clicked(); break;
        case 14: _t->on_pushButton_max_clicked(); break;
        case 15: _t->on_pushButton_poisk_clicked(); break;
        case 16: _t->on_lineEdit_poisk_textChanged(); break;
        case 17: _t->on_pushButton_addrow_clicked(); break;
        case 18: _t->on_pushButton_delrow_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSize,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t

, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double *, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<double *, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 19;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
