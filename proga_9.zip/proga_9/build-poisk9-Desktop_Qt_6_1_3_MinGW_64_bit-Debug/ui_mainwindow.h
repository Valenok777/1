/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.1.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QSpinBox *spinBox_row;
    QComboBox *comboBox_sort;
    QPushButton *pushButton_sort;
    QPushButton *pushButton_max;
    QPushButton *pushButton_srednee;
    QLabel *label_max;
    QPushButton *pushButton_min;
    QLabel *label_Sans;
    QTableWidget *tableWidget;
    QLabel *label_min;
    QLabel *label_vibor;
    QLabel *label_Pans;
    QPushButton *pushButton_clear;
    QPushButton *pushButton_rand;
    QLabel *label_srednee;
    QPushButton *pushButton_poisk;
    QLineEdit *lineEdit_poisk;
    QLabel *label_poisk;
    QLabel *label_kolvo;
    QLabel *label_hislo;
    QTableWidget *tableWidget_2;
    QPushButton *pushButton_addrow;
    QPushButton *pushButton_delrow;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1210, 634);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        spinBox_row = new QSpinBox(centralWidget);
        spinBox_row->setObjectName(QString::fromUtf8("spinBox_row"));
        spinBox_row->setGeometry(QRect(240, 20, 111, 31));
        spinBox_row->setValue(2);
        comboBox_sort = new QComboBox(centralWidget);
        comboBox_sort->addItem(QString());
        comboBox_sort->addItem(QString());
        comboBox_sort->addItem(QString());
        comboBox_sort->addItem(QString());
        comboBox_sort->addItem(QString());
        comboBox_sort->setObjectName(QString::fromUtf8("comboBox_sort"));
        comboBox_sort->setGeometry(QRect(240, 100, 131, 51));
        pushButton_sort = new QPushButton(centralWidget);
        pushButton_sort->setObjectName(QString::fromUtf8("pushButton_sort"));
        pushButton_sort->setGeometry(QRect(240, 300, 131, 51));
        pushButton_max = new QPushButton(centralWidget);
        pushButton_max->setObjectName(QString::fromUtf8("pushButton_max"));
        pushButton_max->setGeometry(QRect(240, 370, 131, 51));
        pushButton_srednee = new QPushButton(centralWidget);
        pushButton_srednee->setObjectName(QString::fromUtf8("pushButton_srednee"));
        pushButton_srednee->setGeometry(QRect(240, 440, 131, 51));
        label_max = new QLabel(centralWidget);
        label_max->setObjectName(QString::fromUtf8("label_max"));
        label_max->setGeometry(QRect(400, 370, 111, 51));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        label_max->setFont(font);
        pushButton_min = new QPushButton(centralWidget);
        pushButton_min->setObjectName(QString::fromUtf8("pushButton_min"));
        pushButton_min->setGeometry(QRect(240, 510, 131, 51));
        label_Sans = new QLabel(centralWidget);
        label_Sans->setObjectName(QString::fromUtf8("label_Sans"));
        label_Sans->setGeometry(QRect(360, 100, 51, 21));
        tableWidget = new QTableWidget(centralWidget);
        if (tableWidget->columnCount() < 1)
            tableWidget->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        if (tableWidget->rowCount() < 2)
            tableWidget->setRowCount(2);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem1);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(0, 0, 221, 581));
        tableWidget->setRowCount(2);
        tableWidget->setColumnCount(1);
        label_min = new QLabel(centralWidget);
        label_min->setObjectName(QString::fromUtf8("label_min"));
        label_min->setGeometry(QRect(400, 510, 111, 51));
        label_min->setFont(font);
        label_vibor = new QLabel(centralWidget);
        label_vibor->setObjectName(QString::fromUtf8("label_vibor"));
        label_vibor->setGeometry(QRect(240, 60, 171, 31));
        QFont font1;
        font1.setBold(true);
        label_vibor->setFont(font1);
        label_Pans = new QLabel(centralWidget);
        label_Pans->setObjectName(QString::fromUtf8("label_Pans"));
        label_Pans->setGeometry(QRect(420, 150, 51, 21));
        pushButton_clear = new QPushButton(centralWidget);
        pushButton_clear->setObjectName(QString::fromUtf8("pushButton_clear"));
        pushButton_clear->setGeometry(QRect(540, 510, 131, 51));
        pushButton_rand = new QPushButton(centralWidget);
        pushButton_rand->setObjectName(QString::fromUtf8("pushButton_rand"));
        pushButton_rand->setGeometry(QRect(240, 230, 131, 51));
        label_srednee = new QLabel(centralWidget);
        label_srednee->setObjectName(QString::fromUtf8("label_srednee"));
        label_srednee->setGeometry(QRect(400, 440, 111, 51));
        label_srednee->setFont(font);
        pushButton_poisk = new QPushButton(centralWidget);
        pushButton_poisk->setObjectName(QString::fromUtf8("pushButton_poisk"));
        pushButton_poisk->setGeometry(QRect(820, 80, 141, 51));
        lineEdit_poisk = new QLineEdit(centralWidget);
        lineEdit_poisk->setObjectName(QString::fromUtf8("lineEdit_poisk"));
        lineEdit_poisk->setGeometry(QRect(820, 150, 141, 31));
        lineEdit_poisk->setFont(font1);
        label_poisk = new QLabel(centralWidget);
        label_poisk->setObjectName(QString::fromUtf8("label_poisk"));
        label_poisk->setGeometry(QRect(610, 155, 171, 21));
        label_poisk->setFont(font1);
        label_kolvo = new QLabel(centralWidget);
        label_kolvo->setObjectName(QString::fromUtf8("label_kolvo"));
        label_kolvo->setGeometry(QRect(610, 200, 171, 31));
        label_kolvo->setFont(font1);
        label_hislo = new QLabel(centralWidget);
        label_hislo->setObjectName(QString::fromUtf8("label_hislo"));
        label_hislo->setGeometry(QRect(830, 200, 121, 31));
        label_hislo->setFont(font1);
        tableWidget_2 = new QTableWidget(centralWidget);
        if (tableWidget_2->columnCount() < 1)
            tableWidget_2->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(0, __qtablewidgetitem2);
        if (tableWidget_2->rowCount() < 2)
            tableWidget_2->setRowCount(2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(0, __qtablewidgetitem3);
        tableWidget_2->setObjectName(QString::fromUtf8("tableWidget_2"));
        tableWidget_2->setGeometry(QRect(980, 0, 221, 581));
        tableWidget_2->setRowCount(2);
        tableWidget_2->setColumnCount(1);
        pushButton_addrow = new QPushButton(centralWidget);
        pushButton_addrow->setObjectName(QString::fromUtf8("pushButton_addrow"));
        pushButton_addrow->setGeometry(QRect(400, 10, 131, 51));
        pushButton_delrow = new QPushButton(centralWidget);
        pushButton_delrow->setObjectName(QString::fromUtf8("pushButton_delrow"));
        pushButton_delrow->setGeometry(QRect(560, 10, 131, 51));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1210, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        comboBox_sort->setItemText(0, QCoreApplication::translate("MainWindow", "\320\221\321\213\321\201\321\202\321\200\320\260\321\217 ", nullptr));
        comboBox_sort->setItemText(1, QCoreApplication::translate("MainWindow", "\320\240\320\260\321\201\321\207\320\265\321\201\320\272\320\260", nullptr));
        comboBox_sort->setItemText(2, QCoreApplication::translate("MainWindow", "\320\237\321\203\320\267\321\213\321\200\321\214\320\272\320\276\320\274", nullptr));
        comboBox_sort->setItemText(3, QCoreApplication::translate("MainWindow", "\320\223\320\275\320\276\320\274\321\214\321\217", nullptr));
        comboBox_sort->setItemText(4, QCoreApplication::translate("MainWindow", "\320\236\320\261\320\265\320\267\321\214\321\217\320\275\321\214\321\217", nullptr));

        pushButton_sort->setText(QCoreApplication::translate("MainWindow", "\320\241\320\276\321\200\321\202\320\270\321\200\320\276\320\262\320\272\320\260", nullptr));
        pushButton_max->setText(QCoreApplication::translate("MainWindow", "\320\234\320\260\320\272\321\201\320\270\320\274\321\203\320\274", nullptr));
        pushButton_srednee->setText(QCoreApplication::translate("MainWindow", "\320\241\321\200\320\265\320\264\320\275\320\265\320\265", nullptr));
        label_max->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        pushButton_min->setText(QCoreApplication::translate("MainWindow", "\320\234\320\270\320\275\320\270\320\274\321\203\320\274", nullptr));
        label_Sans->setText(QString());
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "X", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->verticalHeaderItem(0);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "1", nullptr));
        label_min->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_vibor->setText(QCoreApplication::translate("MainWindow", "\320\241\320\276\321\200\321\202\320\270\321\200\320\276\320\262\320\272\320\270", nullptr));
        label_Pans->setText(QString());
        pushButton_clear->setText(QCoreApplication::translate("MainWindow", "\320\236\321\207\320\270\321\201\321\202\320\272\320\260", nullptr));
        pushButton_rand->setText(QCoreApplication::translate("MainWindow", "\320\220\320\262\321\202\320\276\320\267\320\260\320\277\320\276\320\273\320\275\320\265\320\275\320\270\320\265", nullptr));
        label_srednee->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        pushButton_poisk->setText(QCoreApplication::translate("MainWindow", "\320\237\320\276\320\270\321\201\320\272", nullptr));
        lineEdit_poisk->setText(QString());
        label_poisk->setText(QCoreApplication::translate("MainWindow", "\320\247\320\270\321\201\320\273\320\276 \320\272\320\276\321\202\320\276\321\200\320\276\320\265 \320\275\321\203\320\266\320\275\320\276 \320\275\320\260\320\271\321\202\320\270", nullptr));
        label_kolvo->setText(QCoreApplication::translate("MainWindow", "\320\222\321\205\320\276\320\266\320\264\320\265\320\275\320\270\321\217:", nullptr));
        label_hislo->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget_2->horizontalHeaderItem(0);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("MainWindow", "\320\235\320\276\320\274\320\265\321\200\320\260 \321\201\321\202\321\200\320\276\320\272", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget_2->verticalHeaderItem(0);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("MainWindow", "1", nullptr));
        pushButton_addrow->setText(QCoreApplication::translate("MainWindow", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \321\215\320\273\320\265\320\274\320\265\320\275\321\202", nullptr));
        pushButton_delrow->setText(QCoreApplication::translate("MainWindow", "\320\243\320\261\321\200\320\260\321\202\321\214 \321\215\320\273\320\265\320\274\320\265\320\275\321\202", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
