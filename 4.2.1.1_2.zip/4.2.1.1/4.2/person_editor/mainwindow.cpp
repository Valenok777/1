#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui -> pushButton_clr -> click();
    ui -> lineEdit_scr_lft -> setReadOnly(true);//запрещаем пользователю изменять максимальное колличество очков

    ui->lineEdit_name->setMaxLength(20); //длина имени
    ui->lineEdit_dex->setMaxLength(2);
    ui->lineEdit_har->setMaxLength(2);
    ui->lineEdit_in->setMaxLength(2);
    ui->lineEdit_luck->setMaxLength(2);
    ui->lineEdit_str->setMaxLength(2);


    //Ограничения по характеристике "Сила" для рас
    mas_str_value[0][0] = 1; // люди
    mas_str_value[0][1] = 10;// люди
    mas_str_value[1][0] = 1; // хоббиты
    mas_str_value[1][1] = 8; // хоббиты
    mas_str_value[2][0] = 1; // гномы
    mas_str_value[2][1] = 6; // гномы
    mas_str_value[3][0] = 5; // орки
    mas_str_value[3][1] = 15;// орки

    //Ограничение по характеристике "Ловкость" для рас
    mas_dex_value[0][0] = 1; // люди
    mas_dex_value[0][1] = 10;// люди
    mas_dex_value[1][0] = 1; // хоббиты
    mas_dex_value[1][1] = 12;// хоббиты
    mas_dex_value[2][0] = 1; // гномы
    mas_dex_value[2][1] = 8; // гномы
    mas_dex_value[3][0] = 1; // орки
    mas_dex_value[3][1] = 3; // орки

    //Ограничение по характеристике "Интелект" для рас
    mas_in_value[0][0] = 1; // люди
    mas_in_value[0][1] = 10;// люди
    mas_in_value[1][0] = 1; // хоббиты
    mas_in_value[1][1] = 10;// хоббиты
    mas_in_value[2][0] = 5; // гномы
    mas_in_value[2][1] = 15;// гномы
    mas_in_value[3][0] = 1; // орки
    mas_in_value[3][1] = 3; // орки

    //Ограничение по характеристике "Удача" для рас
    mas_luck_value[0][0] = 3; // люди
    mas_luck_value[0][1] = 6;// люди
    mas_luck_value[1][0] = 4; // хоббиты
    mas_luck_value[1][1] = 8;// хоббиты
    mas_luck_value[2][0] = 3; // гномы
    mas_luck_value[2][1] = 12;// гномы
    mas_luck_value[3][0] = 1; // орки
    mas_luck_value[3][1] = 5; // орки

    //Привлекательность по гендеру
    mas_gender[0][0] = "Красавец";
    mas_gender[0][1] = "Хорош";
    mas_gender[0][2] = "Доволен собой";
    mas_gender[1][0] = "Красавеца";
    mas_gender[1][1] = "Хороша";
    mas_gender[1][2] = "Довольна собой";

    //Класс по гендеру
    mas_gender[0][3] = "Варвар";
    mas_gender[0][4] = "Паладин";
    mas_gender[0][5] = "Маг";
    mas_gender[1][3] = "Убийца";
    mas_gender[1][4] = "Воительница";
    mas_gender[1][5] = "Колдунья";

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clr_clicked()// очистка введеных данных
{
    ui -> lineEdit_name -> clear();
    ui -> lineEdit_dex -> clear();
    ui -> lineEdit_str -> clear();
    ui -> lineEdit_in -> clear();
    ui -> lineEdit_luck -> clear();
    ui -> lineEdit_har -> clear();

    ui -> lineEdit_scr_lft -> setText("25");

    ui -> label_hp_val -> clear();
    ui -> label_mp_val -> clear();
    ui -> label_atk_val -> clear();
    ui -> label_def_val -> clear();
    ui -> label_class_val -> clear();
    ui -> label_priv_val ->  clear();

    ui -> radioButton_sex_m -> setChecked(true);

}

void MainWindow::on_pushButton_create_clicked()//характеристики
{
    int str, dex, inte, luck, har; // характеристики
    QString name;           // имя персанажа
    int dlina;              // длина имени
    bool fl;                // признак успешной генерации
    int kod_race = ui -> comboBox_race -> currentIndex();


    name = ui ->lineEdit_name -> text();
    dlina = name.length(); //длина строки
    if((dlina < 3)||(dlina > 20))
    {
        fl = false;
        QMessageBox::information(this,"Ошибка","Имя должно быть длиной от 3 до 20.",QMessageBox::Ok);
    }
    else
        fl = true;


    str = 0;
    dex = 0;
    inte = 0;
    luck = 0;

    if(fl)
    {
        // проверка параметра "Сила"
        str = ui -> lineEdit_str -> text().toInt(&fl);
        if(fl)//вместо вложенных if
        {
            if((str < mas_str_value[kod_race][0]) || (str > mas_str_value[kod_race][1]))
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Параметр \"Сила\" должен быть от " + QString::number(mas_str_value[kod_race][0]) + " до " + QString::number(mas_str_value[kod_race][1]) + ".", QMessageBox::Ok);
            }
        }
        else
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Сила\"",QMessageBox::Ok);
    }

    if(fl)
    {
        // проверка параметра "Ловкость"
        dex = ui -> lineEdit_dex -> text().toInt(&fl);
        if(fl)//вместо вложенных if
        {
            if((dex < mas_dex_value[kod_race][0]) || (dex > mas_dex_value[kod_race][1]))
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Параметр \"Ловкость\" должен быть от " + QString::number(mas_dex_value[kod_race][0]) + " до " + QString::number(mas_dex_value[kod_race][1]) + ".", QMessageBox::Ok);
            }
        }
        else
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Ловкость\".",QMessageBox::Ok);
    }

    if(fl)
    {
        // проверка параметра "Интелект"
        inte = ui -> lineEdit_in -> text().toInt(&fl);
        if(fl)//вместо вложенных if
        {
            if((inte < mas_in_value[kod_race][0]) || (inte > mas_in_value[kod_race][1]))
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Параметр \"Интелект\" должен быть от " + QString::number(mas_in_value[kod_race][0]) + " до " + QString::number(mas_in_value[kod_race][1]) + ".", QMessageBox::Ok);
            }
        }
        else
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Интелект\".",QMessageBox::Ok);
    }

    if(fl)
    {
        // проверка параметра "Харизма"
        har = ui -> lineEdit_har -> text().toInt(&fl);
        if(fl)//вместо вложенных if
        {
            if((har < 2) || (har > 10))
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Параметр \"Харизма\" должен быть от 1 до 10.", QMessageBox::Ok);
            }
        }
        else
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Харизма\".",QMessageBox::Ok);
    }

    if(fl)
    {
        // проверка параметра "Удача"
        luck = ui -> lineEdit_luck -> text().toInt(&fl);
        if(fl)//вместо вложенных if
        {
            if((luck < mas_luck_value[kod_race][0]) || (luck > mas_luck_value[kod_race][1]))
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Параметр \"Удача\" должен быть от " + QString::number(mas_luck_value[kod_race][0]) + " до " + QString::number(mas_luck_value[kod_race][1]) + ".", QMessageBox::Ok);
            }
        }
        else
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Удача\".",QMessageBox::Ok);
    }
    //счетчик
    if(fl)
    {
        int scr_lft = 25 - str - dex - inte - luck - har;
        ui -> lineEdit_scr_lft -> setText(QString::number(scr_lft));
        if(scr_lft < 0)
        {
            fl = false;
            QMessageBox::information(this,"Ошибка","Нельзя тратить больше 25 очков",QMessageBox::Ok);
        }

        else
        {
            if(scr_lft > 0)
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Надо потратить все очки",QMessageBox::Ok);
            }
        }
    }

    if(fl) // вывод получившихся характеристик
    {
        int hp, mp, def, atk, priv, kod_gender = 0;
        def = 6 * str + 2 * dex + 2 * luck;                 // защита
        atk = 7 * dex + 3 * luck + 2 * str;                 // атака
        hp = 8 * str + 2 * def;                             // здоровье
        mp = 8 * inte + dex + luck;                           // мана
        priv = 3 * str + dex + 3 * inte + 2 * luck + 3 * har; // привлекательность


        ui -> label_hp_val -> setNum(hp);
        ui -> label_mp_val -> setNum(mp);
        ui -> label_def_val -> setNum(def);
        ui -> label_atk_val -> setNum(atk);

        // Генерация привлекательности
        if (priv > 55) ui -> label_priv_val -> setText(mas_gender[function_gender(kod_gender)][0]);
        else if (priv > 45) ui -> label_priv_val -> setText(mas_gender[function_gender(kod_gender)][1]);
        else if (priv > 35) ui -> label_priv_val -> setText(mas_gender[function_gender(kod_gender)][2]);

        //Генерация класса
        if (atk > mp && atk > def) ui -> label_class_val -> setText(mas_gender[function_gender(kod_gender)][3]);
        else if (def > mp && def > atk) ui -> label_class_val -> setText(mas_gender[function_gender(kod_gender)][4]);
        else if (mp > def && mp > atk) ui -> label_class_val -> setText(mas_gender[function_gender(kod_gender)][5]);

    }
    else // очистка параметров здровоья, маны, атаки, защиты, класса
    {
        ui -> label_hp_val -> clear();
        ui -> label_mp_val -> clear();
        ui -> label_atk_val -> clear();
        ui -> label_def_val -> clear();
        ui -> label_class_val -> clear();
        ui -> label_priv_val -> clear();
    }
}

int MainWindow::function_gender(int kod_gender)
{
    if (ui->radioButton_sex_w->isChecked())
        kod_gender = 1;
    else
        kod_gender = 0;
    return kod_gender;
}

void MainWindow::on_lineEdit_name_textChanged(const QString &) //изменение имени
{
    int dlina=ui->lineEdit_name->text().length();

    QPalette pal=ui->lineEdit_name->palette();

    if((dlina < 3)||(dlina > 20))
    {
        pal.setColor(QPalette::Text,Qt::red);
    }
    else
    {
        pal.setColor(QPalette::Text,Qt::green);
    }
    ui->lineEdit_name->setPalette(pal);
}

void MainWindow::on_lineEdit_str_textChanged(const QString &)
{
    int valp=ui->lineEdit_str->text().toInt();
    int kod_race=ui->comboBox_race->currentIndex();

    QPalette pal=ui->lineEdit_str->palette();

    if((valp < mas_str_value[kod_race][0]) || (valp > mas_str_value[kod_race][1]))
    {
        pal.setColor(QPalette::Text,Qt::red);
    }
    else
    {
        pal.setColor(QPalette::Text,Qt::green);
    }
    ui->lineEdit_str->setPalette(pal);
}

void MainWindow::on_lineEdit_dex_textChanged(const QString &)
{
    int DEX=ui->lineEdit_dex->text().toInt();
    int kod_race=ui->comboBox_race->currentIndex();

    QPalette pal=ui->lineEdit_dex->palette();

    if((DEX < mas_dex_value[kod_race][0]) || (DEX > mas_dex_value[kod_race][1]))
    {
        pal.setColor(QPalette::Text,Qt::red);
    }
    else
    {
        pal.setColor(QPalette::Text,Qt::green);
    }
    ui->lineEdit_dex->setPalette(pal);
}

void MainWindow::on_lineEdit_scr_lft_textChanged(const QString &)
{
    int str, dex, inte, luck, har, score_left;
    str=ui->lineEdit_str->text().toInt();
    dex=ui->lineEdit_dex->text().toInt();
    inte=ui->lineEdit_in->text().toInt();
    luck=ui->lineEdit_luck->text().toInt();
    har=ui->lineEdit_har->text().toInt();
    score_left = 25 - str - dex - inte - luck - har;



    QPalette pal=ui->lineEdit_scr_lft->palette();


}
