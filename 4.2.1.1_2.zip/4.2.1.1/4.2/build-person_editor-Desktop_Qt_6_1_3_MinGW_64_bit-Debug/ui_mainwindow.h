/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.1.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *label_name;
    QLineEdit *lineEdit_name;
    QLabel *label_sex;
    QLineEdit *lineEdit_str;
    QLineEdit *lineEdit_dex;
    QLineEdit *lineEdit_in;
    QLabel *label_str;
    QLabel *label_dex;
    QLabel *label_in;
    QLineEdit *lineEdit_luck;
    QLabel *label_luck;
    QLineEdit *lineEdit_scr_lft;
    QLabel *label_pts_lft;
    QPushButton *pushButton_clr;
    QPushButton *pushButton_create;
    QFrame *line;
    QFrame *line_2;
    QLabel *label_hp;
    QLabel *label_hp_val;
    QLabel *label_mp_val;
    QLabel *label_mp;
    QLabel *label_def_val;
    QLabel *label_def;
    QLabel *label_atk_val;
    QLabel *label_atk;
    QLabel *label_class_val;
    QLabel *label_class;
    QLabel *label_race;
    QComboBox *comboBox_race;
    QLabel *label_har;
    QLineEdit *lineEdit_har;
    QLabel *label_priv;
    QLabel *label_priv_val;
    QGroupBox *groupBox;
    QRadioButton *radioButton_sex_m;
    QRadioButton *radioButton_sex_w;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(963, 462);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        label_name = new QLabel(centralWidget);
        label_name->setObjectName(QString::fromUtf8("label_name"));
        label_name->setGeometry(QRect(30, 20, 47, 21));
        lineEdit_name = new QLineEdit(centralWidget);
        lineEdit_name->setObjectName(QString::fromUtf8("lineEdit_name"));
        lineEdit_name->setGeometry(QRect(160, 20, 191, 20));
        label_sex = new QLabel(centralWidget);
        label_sex->setObjectName(QString::fromUtf8("label_sex"));
        label_sex->setGeometry(QRect(30, 50, 47, 21));
        lineEdit_str = new QLineEdit(centralWidget);
        lineEdit_str->setObjectName(QString::fromUtf8("lineEdit_str"));
        lineEdit_str->setGeometry(QRect(160, 90, 51, 20));
        lineEdit_dex = new QLineEdit(centralWidget);
        lineEdit_dex->setObjectName(QString::fromUtf8("lineEdit_dex"));
        lineEdit_dex->setGeometry(QRect(160, 120, 51, 20));
        lineEdit_in = new QLineEdit(centralWidget);
        lineEdit_in->setObjectName(QString::fromUtf8("lineEdit_in"));
        lineEdit_in->setGeometry(QRect(160, 150, 51, 20));
        label_str = new QLabel(centralWidget);
        label_str->setObjectName(QString::fromUtf8("label_str"));
        label_str->setGeometry(QRect(30, 90, 47, 21));
        label_dex = new QLabel(centralWidget);
        label_dex->setObjectName(QString::fromUtf8("label_dex"));
        label_dex->setGeometry(QRect(30, 120, 81, 21));
        label_in = new QLabel(centralWidget);
        label_in->setObjectName(QString::fromUtf8("label_in"));
        label_in->setGeometry(QRect(30, 150, 61, 20));
        lineEdit_luck = new QLineEdit(centralWidget);
        lineEdit_luck->setObjectName(QString::fromUtf8("lineEdit_luck"));
        lineEdit_luck->setGeometry(QRect(160, 210, 51, 20));
        label_luck = new QLabel(centralWidget);
        label_luck->setObjectName(QString::fromUtf8("label_luck"));
        label_luck->setGeometry(QRect(30, 210, 47, 21));
        lineEdit_scr_lft = new QLineEdit(centralWidget);
        lineEdit_scr_lft->setObjectName(QString::fromUtf8("lineEdit_scr_lft"));
        lineEdit_scr_lft->setGeometry(QRect(160, 270, 51, 21));
        label_pts_lft = new QLabel(centralWidget);
        label_pts_lft->setObjectName(QString::fromUtf8("label_pts_lft"));
        label_pts_lft->setGeometry(QRect(30, 270, 101, 20));
        pushButton_clr = new QPushButton(centralWidget);
        pushButton_clr->setObjectName(QString::fromUtf8("pushButton_clr"));
        pushButton_clr->setGeometry(QRect(90, 340, 75, 23));
        pushButton_create = new QPushButton(centralWidget);
        pushButton_create->setObjectName(QString::fromUtf8("pushButton_create"));
        pushButton_create->setGeometry(QRect(200, 340, 75, 23));
        line = new QFrame(centralWidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(10, 310, 351, 20));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        line_2 = new QFrame(centralWidget);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(350, 0, 20, 371));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);
        label_hp = new QLabel(centralWidget);
        label_hp->setObjectName(QString::fromUtf8("label_hp"));
        label_hp->setGeometry(QRect(400, 30, 81, 20));
        label_hp_val = new QLabel(centralWidget);
        label_hp_val->setObjectName(QString::fromUtf8("label_hp_val"));
        label_hp_val->setGeometry(QRect(550, 30, 121, 21));
        label_mp_val = new QLabel(centralWidget);
        label_mp_val->setObjectName(QString::fromUtf8("label_mp_val"));
        label_mp_val->setGeometry(QRect(550, 60, 71, 21));
        label_mp = new QLabel(centralWidget);
        label_mp->setObjectName(QString::fromUtf8("label_mp"));
        label_mp->setGeometry(QRect(400, 60, 47, 21));
        label_def_val = new QLabel(centralWidget);
        label_def_val->setObjectName(QString::fromUtf8("label_def_val"));
        label_def_val->setGeometry(QRect(550, 90, 191, 21));
        label_def = new QLabel(centralWidget);
        label_def->setObjectName(QString::fromUtf8("label_def"));
        label_def->setGeometry(QRect(400, 90, 47, 21));
        label_atk_val = new QLabel(centralWidget);
        label_atk_val->setObjectName(QString::fromUtf8("label_atk_val"));
        label_atk_val->setGeometry(QRect(550, 120, 181, 21));
        label_atk = new QLabel(centralWidget);
        label_atk->setObjectName(QString::fromUtf8("label_atk"));
        label_atk->setGeometry(QRect(400, 120, 47, 21));
        label_class_val = new QLabel(centralWidget);
        label_class_val->setObjectName(QString::fromUtf8("label_class_val"));
        label_class_val->setGeometry(QRect(550, 180, 91, 21));
        label_class = new QLabel(centralWidget);
        label_class->setObjectName(QString::fromUtf8("label_class"));
        label_class->setGeometry(QRect(400, 180, 47, 21));
        label_race = new QLabel(centralWidget);
        label_race->setObjectName(QString::fromUtf8("label_race"));
        label_race->setGeometry(QRect(30, 240, 47, 21));
        comboBox_race = new QComboBox(centralWidget);
        comboBox_race->addItem(QString());
        comboBox_race->addItem(QString());
        comboBox_race->addItem(QString());
        comboBox_race->addItem(QString());
        comboBox_race->setObjectName(QString::fromUtf8("comboBox_race"));
        comboBox_race->setGeometry(QRect(160, 240, 161, 22));
        label_har = new QLabel(centralWidget);
        label_har->setObjectName(QString::fromUtf8("label_har"));
        label_har->setGeometry(QRect(30, 180, 71, 21));
        lineEdit_har = new QLineEdit(centralWidget);
        lineEdit_har->setObjectName(QString::fromUtf8("lineEdit_har"));
        lineEdit_har->setGeometry(QRect(160, 180, 51, 20));
        label_priv = new QLabel(centralWidget);
        label_priv->setObjectName(QString::fromUtf8("label_priv"));
        label_priv->setGeometry(QRect(400, 150, 121, 20));
        label_priv_val = new QLabel(centralWidget);
        label_priv_val->setObjectName(QString::fromUtf8("label_priv_val"));
        label_priv_val->setGeometry(QRect(550, 150, 131, 21));
        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setEnabled(true);
        groupBox->setGeometry(QRect(160, 50, 191, 31));
        radioButton_sex_m = new QRadioButton(groupBox);
        radioButton_sex_m->setObjectName(QString::fromUtf8("radioButton_sex_m"));
        radioButton_sex_m->setGeometry(QRect(10, 7, 82, 20));
        radioButton_sex_w = new QRadioButton(groupBox);
        radioButton_sex_w->setObjectName(QString::fromUtf8("radioButton_sex_w"));
        radioButton_sex_w->setGeometry(QRect(100, 7, 81, 20));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 963, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label_name->setText(QCoreApplication::translate("MainWindow", "\320\230\320\274\321\217", nullptr));
        label_sex->setText(QCoreApplication::translate("MainWindow", "\320\237\320\276\320\273", nullptr));
        label_str->setText(QCoreApplication::translate("MainWindow", "\320\241\320\270\320\273\320\260", nullptr));
        label_dex->setText(QCoreApplication::translate("MainWindow", "\320\233\320\276\320\262\320\272\320\276\321\201\321\202\321\214", nullptr));
        label_in->setText(QCoreApplication::translate("MainWindow", "\320\230\320\275\321\202\320\265\320\273\320\273\320\265\320\272\321\202", nullptr));
        label_luck->setText(QCoreApplication::translate("MainWindow", "\320\243\320\264\320\260\321\207\320\260", nullptr));
        label_pts_lft->setText(QCoreApplication::translate("MainWindow", "\320\236\321\201\321\202\320\260\320\273\320\276\321\201\321\214 \320\276\321\207\320\272\320\276\320\262", nullptr));
        pushButton_clr->setText(QCoreApplication::translate("MainWindow", "\320\236\321\207\320\270\321\201\321\202\320\270\321\202\321\214", nullptr));
        pushButton_create->setText(QCoreApplication::translate("MainWindow", "\320\241\320\276\320\267\320\264\320\260\321\202\321\214", nullptr));
        label_hp->setText(QCoreApplication::translate("MainWindow", "\320\227\320\264\320\276\321\200\320\276\320\262\321\214\320\265", nullptr));
        label_hp_val->setText(QCoreApplication::translate("MainWindow", "\320\237\320\276\321\207\321\202\320\270 \320\275\320\265 \320\276\321\201\321\202\320\260\320\273\320\276\321\201\321\202\321\214", nullptr));
        label_mp_val->setText(QCoreApplication::translate("MainWindow", "\320\247\321\202\320\276 \321\215\321\202\320\276?", nullptr));
        label_mp->setText(QCoreApplication::translate("MainWindow", "\320\234\320\260\320\275\320\260", nullptr));
        label_def_val->setText(QCoreApplication::translate("MainWindow", "\320\234\320\276\320\266\320\275\320\276 \320\277\320\276\320\277\321\200\320\276\320\261\320\276\320\262\320\260\321\202\321\214 \321\203\320\261\320\265\320\266\320\260\321\202\321\214", nullptr));
        label_def->setText(QCoreApplication::translate("MainWindow", "\320\227\320\260\321\211\320\270\321\202\320\260", nullptr));
        label_atk_val->setText(QCoreApplication::translate("MainWindow", "\320\223\320\273\320\260\320\262\320\275\320\276\320\265 \320\275\320\265 \320\277\320\276\321\200\320\260\320\275\320\270\321\202\321\214 \321\201\320\265\320\261\321\217", nullptr));
        label_atk->setText(QCoreApplication::translate("MainWindow", "\320\220\321\202\320\260\320\272\320\260", nullptr));
        label_class_val->setText(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\264\320\276\321\205\320\273\320\270\320\272", nullptr));
        label_class->setText(QCoreApplication::translate("MainWindow", "\320\232\320\273\320\260\321\201\321\201", nullptr));
        label_race->setText(QCoreApplication::translate("MainWindow", "\320\240\320\260\321\201\320\260", nullptr));
        comboBox_race->setItemText(0, QCoreApplication::translate("MainWindow", "\320\233\321\216\320\264\320\270", nullptr));
        comboBox_race->setItemText(1, QCoreApplication::translate("MainWindow", "\320\245\320\276\320\261\320\261\320\270\321\202\321\213", nullptr));
        comboBox_race->setItemText(2, QCoreApplication::translate("MainWindow", "\320\223\320\275\320\276\320\274\321\213", nullptr));
        comboBox_race->setItemText(3, QCoreApplication::translate("MainWindow", "\320\236\321\200\320\272\320\270", nullptr));

        label_har->setText(QCoreApplication::translate("MainWindow", "\320\245\320\260\321\200\320\270\320\267\320\274\320\260", nullptr));
        label_priv->setText(QCoreApplication::translate("MainWindow", "\320\237\321\200\320\270\320\262\320\273\320\265\320\272\320\260\321\202\320\265\320\273\321\214\320\275\320\276\321\201\321\202\321\214", nullptr));
        label_priv_val->setText(QCoreApplication::translate("MainWindow", "\320\257 \320\273\321\203\321\207\321\210\320\270\320\271?", nullptr));
        groupBox->setTitle(QString());
        radioButton_sex_m->setText(QCoreApplication::translate("MainWindow", "\320\234\321\203\320\266\321\201\320\272\320\276\320\271", nullptr));
        radioButton_sex_w->setText(QCoreApplication::translate("MainWindow", "\320\226\320\265\320\275\321\201\320\272\320\270\320\271", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
