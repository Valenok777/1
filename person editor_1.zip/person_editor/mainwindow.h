#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMessageBox>// libra message

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clr_clicked();

    void on_pushButton_create_clicked();

    int function_gender(int kod_gender);

    void function_image(int kod_race, int clss);

    void clear_result();

private:
    Ui::MainWindow *ui;
    int mas_str_value[4][2];        // сила для 4 рас - минимум и максимум
    int mas_dex_value[4][2];        // ловкость для 4 рас - минимум и максимум
    int mas_in_value[4][2];         // интелект для 4 рас - минимум и максимум
    int mas_luck_value[4][2];       // удача для 4 рас - минимум и максимум

    QString mas_gender[2][6];       // гендер
    QString mas_description[2][3];  // описание классов
    QString mas_img[2][12];         // картинки к классам
    int mas_index[4][3] { {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, {9, 10, 11}}; // массив из элементов расс и классов
};

#endif // MAINWINDOW_H
