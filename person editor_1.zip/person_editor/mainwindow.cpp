#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui -> pushButton_clr -> click();
    ui -> lineEdit_scr_lft -> setReadOnly(true);//запрещаем пользователю изменять максимальное колличество очков

    //Лимит по характеристике "Сила" для рас
    mas_str_value[0][0] = 4; // люди
    mas_str_value[0][1] = 10;// люди
    mas_str_value[1][0] = 3; // эльфы
    mas_str_value[1][1] = 8; // эльфы
    mas_str_value[2][0] = 3; // гномы
    mas_str_value[2][1] = 8; // гномы
    mas_str_value[3][0] = 5; // орки
    mas_str_value[3][1] = 12;// орки

    //Лимит по характеристике "Ловкость" для рас
    mas_dex_value[0][0] = 4; // люди
    mas_dex_value[0][1] = 10;// люди
    mas_dex_value[1][0] = 5; // эльфы
    mas_dex_value[1][1] = 12;// эльфы
    mas_dex_value[2][0] = 3; // гномы
    mas_dex_value[2][1] = 8; // гномы
    mas_dex_value[3][0] = 3; // орки
    mas_dex_value[3][1] = 8; // орки

    //Лимит по характеристике "Интелект" для рас
    mas_in_value[0][0] = 4; // люди
    mas_in_value[0][1] = 10;// люди
    mas_in_value[1][0] = 4; // эльфы
    mas_in_value[1][1] = 10;// эльфы
    mas_in_value[2][0] = 5; // гномы
    mas_in_value[2][1] = 12;// гномы
    mas_in_value[3][0] = 2; // орки
    mas_in_value[3][1] = 8; // орки

    //Лимит по характеристике "Удача" для рас
    mas_luck_value[0][0] = 3; // люди
    mas_luck_value[0][1] = 10;// люди
    mas_luck_value[1][0] = 3; // эльфы
    mas_luck_value[1][1] = 10;// эльфы
    mas_luck_value[2][0] = 4; // гномы
    mas_luck_value[2][1] = 12;// гномы
    mas_luck_value[3][0] = 2; // орки
    mas_luck_value[3][1] = 8; // орки

//    //Привлекательность по гендеру
//    mas_gender[0][0] = "Красавец";
//    mas_gender[0][1] = "Хорош";
//    mas_gender[0][2] = "Доволен собой";
//    mas_gender[1][0] = "Красавеца";
//    mas_gender[1][1] = "Хороша";
//    mas_gender[1][2] = "Довольна собой";

    //Класс по гендеру
    mas_gender[0][3] = "Ассасин";
    mas_gender[0][4] = "Воин";
    mas_gender[0][5] = "Маг";
    mas_gender[1][3] = "Убийца";
    mas_gender[1][4] = "Воительница";
    mas_gender[1][5] = "Колдунья";

    //Описание классов
    QString EndOfLine("\n");
    mas_description[0][0] = "        Ассасин — настоящий убийца с возможностью уйти в неви-\nдимость. Безжалостны и способны нанести смертельный урон со\nспины по своему врагу в любой неподходящий момент.";
    mas_description[0][1] = "        Воин может выступать либо в роли защитника — «танка»\nпод прикрытием щита, либо в роли безжалостной боевой маши-\nны, либо и того и другого одновременно.";
    mas_description[0][2] = "        Маг уничтожает врагов тайными заклинаниями. Несмотря \nна магическую силу, маги хрупкие, не носят тяжелые доспехи,\nпоэтому уязвимы в ближнем бою.";
    mas_description[1][0] = "        Скрываясь в тени, убийца всегда знает местонахождение \nсвоей цели и готова в любую минуту обрушить серию сокруши-\nтельных ударов в спину врагов. В арсенале убийцы также имеет-\nся телепортация и возможность метания ножей.";
    mas_description[1][1] = "        Женщина-воительница, отличающаяся благородным изя-\nществом, достоинством и сдержанностью, как в бою, так и вне \nего, мудрая, терпеливая и элегантная. Это не просто бой-баба, \nэто — леди! Даже если она родилась в канаве.";
    mas_description[1][2] = "        Колдунья — управляет целым арсеналом элементальной \nмагии. Она не любит, когда враги находится возле её ног, по-\nэтому способна уничтожить их до того, как они до неё добе-\nрутся.";

    //Картинки
    //Люди
    mas_img[0][0] = ":/resurse/class_img/assasin.jpg";
    mas_img[0][1] = ":/resurse/class_img/berserk-voin-zima-shchit-mech-shlem-art.jpg";
    mas_img[0][2] = ":/resurse/class_img/mag.png";
    mas_img[1][0] = ":/resurse/class_img/ybiza.jpg";
    mas_img[1][1] = ":/resurse/class_img/voitelnizajpg.jpg";
    mas_img[1][2] = ":/resurse/class_img/volshebniza.png";
    //Эльфы
    mas_img[0][3] = ":/elph/class_img/elph_assasin.jfif";
    mas_img[0][4] = ":/elph/class_img/elph_voin.jpg";
    mas_img[0][5] = ":/elph/class_img/elph_mag.png";
    mas_img[1][3] = ":/elph/class_img/elph_ybiza.jpg";
    mas_img[1][4] = ":/elph/class_img/elph_voitelniza.jpg";
    mas_img[1][5] = ":/elph/class_img/elph_volshebniza.jpg";
    //Гномы
    mas_img[0][6] = ":/gnom/class_img/gnom_assasin.jpg";
    mas_img[0][7] = ":/gnom/class_img/gnom_voin.jfif";
    mas_img[0][8] = ":/gnom/class_img/gnom_mag.jpg";
    mas_img[1][6] = ":/gnom/class_img/gnom_ybiza.jpg";
    mas_img[1][7] = ":/gnom/class_img/gnom_voitelniza.png";
    mas_img[1][8] = ":/gnom/class_img/gnom_volshebniza.jpg";
    //Орки
    mas_img[0][9] = ":/orck/class_img/orck_assasin.jpg";
    mas_img[0][10] = ":/orck/class_img/ork_voin.jfif";
    mas_img[0][11] = ":/orck/class_img/orck_mag.jpg";
    mas_img[1][9] = ":/orck/class_img/ybiza_orck.jpg";
    mas_img[1][10] = ":/orck/class_img/fantastika_ork_topor.jpg";
    mas_img[1][11] = ":/orck/class_img/orck_volchebniza.png";
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clr_clicked()// очистка введеных данных
{
    ui -> lineEdit_name -> clear();
    ui -> lineEdit_dex -> clear();
    ui -> lineEdit_str -> clear();
    ui -> lineEdit_in -> clear();
    ui -> lineEdit_luck -> clear();
    ui -> lineEdit_har -> clear();

    ui -> lineEdit_scr_lft -> setText("25");

    ui -> label_hp_val -> clear();
    ui -> label_mp_val -> clear();
    ui -> label_atk_val -> clear();
    ui -> label_def_val -> clear();
    ui -> label_class_val -> clear();
    ui -> label_priv_val ->  clear();
    ui -> label_description -> clear();
    ui -> label_img -> clear();

    ui -> radioButton_sex_m -> setChecked(true);
}

void MainWindow::on_pushButton_create_clicked()//характеристики
{
    int str, dex, in, luck, har;    // характеристики
    QString name;                   // имя персанажа
    int dlina;                      // длина имени
    bool fl;                        // признак успешной генерации
    int kod_race = ui -> comboBox_race -> currentIndex();


    name = ui ->lineEdit_name -> text();
    dlina = name.length(); //длина строки
    if((dlina < 3)||(dlina > 20))
    {
        fl = false;
        QMessageBox::information(this,"Ошибка","Имя должно быть длиной от 3 до 20.",QMessageBox::Ok);
    }
    else
        fl = true;


    if(fl)// проверка параметра "Сила"
    {
        str = ui -> lineEdit_str -> text().toInt(&fl);
        if(fl)
        {
            if((str < mas_str_value[kod_race][0]) || (str > mas_str_value[kod_race][1]))
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Параметр \"Сила\" должен быть от " + QString::number(mas_str_value[kod_race][0]) + " до " + QString::number(mas_str_value[kod_race][1]) + ".", QMessageBox::Ok);
            }
        }
        else
        {
            fl = false;
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Сила\"",QMessageBox::Ok);
        }
    }

    if(fl)// проверка параметра "Ловкость"
    {
        dex = ui -> lineEdit_dex -> text().toInt(&fl);
        if(fl)
        {
            if((dex < mas_dex_value[kod_race][0]) || (dex > mas_dex_value[kod_race][1]))
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Параметр \"Ловкость\" должен быть от " + QString::number(mas_dex_value[kod_race][0]) + " до " + QString::number(mas_dex_value[kod_race][1]) + ".", QMessageBox::Ok);
            }
        }
        else
        {
            fl = false;
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Ловкость\".",QMessageBox::Ok);
        }
    }

    if(fl)// проверка параметра "Интелект"
    {
        in = ui -> lineEdit_in -> text().toInt(&fl);
        if(fl)
        {
            if((in < mas_in_value[kod_race][0]) || (in > mas_in_value[kod_race][1]))
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Параметр \"Интелект\" должен быть от " + QString::number(mas_in_value[kod_race][0]) + " до " + QString::number(mas_in_value[kod_race][1]) + ".", QMessageBox::Ok);
            }
        }
        else
        {
            fl = false;
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Интелект\".",QMessageBox::Ok);
        }
    }

    if(fl)// проверка параметра "Удача"
    {
        luck = ui -> lineEdit_luck -> text().toInt(&fl);
        if(fl)
        {
            if((luck < mas_luck_value[kod_race][0]) || (luck > mas_luck_value[kod_race][1]))
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Параметр \"Удача\" должен быть от " + QString::number(mas_luck_value[kod_race][0]) + " до " + QString::number(mas_luck_value[kod_race][1]) + ".", QMessageBox::Ok);
            }
        }
        else
        {
            fl = false;
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Удача\".",QMessageBox::Ok);
        }
    }

    if(fl)// проверка параметра "Харизма"
    {
        har = ui -> lineEdit_har -> text().toInt(&fl);
        if(fl)
        {
            if((har < 0) || (har > 5))
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Параметр \"Харизма\" должен быть от 1 до 5.", QMessageBox::Ok);
            }
        }
        else
        {
            fl = false;
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Харизма\".",QMessageBox::Ok);
        }
    }

    //счетчик
    if(fl)
    {
        int scr_lft = 25 - str - dex - in - luck - har;
        ui -> lineEdit_scr_lft -> setText(QString::number(scr_lft));
        if(scr_lft < 0)
        {
            fl = false;
            QMessageBox::information(this,"Ошибка","Нельзя тратить больше 25 очков",QMessageBox::Ok);

        }

        else
        {
            if(scr_lft > 0)
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Надо потратить все очки",QMessageBox::Ok);

            }
        }
    }

    if(fl) // вывод получившихся характеристик
    {
        int hp, mp, def, atk, priv, clss, kod_gender = 0;
        def = 6 * str + 2 * dex + 2 * luck;                 // защита
        atk = 5 * dex + 3 * luck + 2 * str;                 // атака
        hp = 8 * str + 2 * def;                             // здоровье
        mp = 8 * in + dex + luck;                           // мана
        priv = 3 * str + 2 * dex + 2 * in + luck + 3 * har; // привлекательность


        ui -> label_hp_val -> setNum(hp);
        ui -> label_mp_val -> setNum(mp);
        ui -> label_def_val -> setNum(def);
        ui -> label_atk_val -> setNum(atk);
        ui -> label_priv_val -> setNum(priv);

//        // Генерация привлекательности
//        if (priv > 55) ui -> label_priv_val -> setText(mas_gender[function_gender(kod_gender)][0]);
//        else if (priv > 45) ui -> label_priv_val -> setText(mas_gender[function_gender(kod_gender)][1]);
//        else if (priv > 35) ui -> label_priv_val -> setText(mas_gender[function_gender(kod_gender)][2]);

        //Генерация описания и класса
        if (atk > mp && atk > def)
        {
            ui -> label_class_val -> setText(mas_gender[function_gender(kod_gender)][3]);
            ui -> label_description -> setText(mas_description[function_gender(kod_gender)][0]);
            clss = 0;
            function_image(kod_race, clss);
        }
        else if (def > mp && def > atk)
        {
            ui -> label_class_val -> setText(mas_gender[function_gender(kod_gender)][4]);
            ui -> label_description -> setText(mas_description[function_gender(kod_gender)][1]);
            clss = 1;
            function_image(kod_race, clss);
        }
        else if (mp > def && mp > atk)
        {
            ui -> label_class_val -> setText(mas_gender[function_gender(kod_gender)][5]);
            ui -> label_description -> setText(mas_description[function_gender(kod_gender)][2]);
            clss = 2;
            function_image(kod_race, clss);
        }
        else if(atk == def)
        {
            ui -> label_class_val -> setText(mas_gender[function_gender(kod_gender)][3] + "-"  +mas_gender[function_gender(kod_gender)][4]);
            ui -> label_description -> setText("Мультикласс");
        }
        else if(atk == in)
        {
            ui -> label_class_val -> setText(mas_gender[function_gender(kod_gender)][3] + "-"  +mas_gender[function_gender(kod_gender)][5]);
            ui -> label_description -> setText("Мультикласс");
        }
        else if(def == in)
        {
            ui -> label_class_val -> setText(mas_gender[function_gender(kod_gender)][4] + "-"  +mas_gender[function_gender(kod_gender)][5]);
            ui -> label_description -> setText("Мультикласс");
        }
    }
    else // очистка параметров здровоья, маны, атаки, защиты, класса
    {
        clear_result(); // функция очистки
    }
}


int MainWindow::function_gender(int kod_gender)
{
    if (ui->radioButton_sex_w->isChecked())
        kod_gender = 1;
    else
        kod_gender = 0;
    return kod_gender;
}

void MainWindow::function_image(int kod_race, int clss)
{
    int index, kod_gender = 0;
    index = mas_index[kod_race][clss];
    QPixmap pix(mas_img[function_gender(kod_gender)][index]);
    int w = ui -> label_img -> width();
    int h = ui -> label_img -> height();
    ui -> label_img -> setPixmap(pix.scaled(w, h, Qt::KeepAspectRatio));
}

void MainWindow::clear_result()
{
    ui -> label_hp_val -> clear();
    ui -> label_mp_val -> clear();
    ui -> label_atk_val -> clear();
    ui -> label_def_val -> clear();
    ui -> label_class_val -> clear();
    ui -> label_description -> clear();
    ui -> label_img -> clear();
    ui -> label_priv_val -> clear();
}


