#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <math.h> // библиотека - "матиматика"
#include <QtMath> // библиотека - "матиматика"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    no_auto_change=true;
    ui->spinBox->setMaximum(MAX_MAS_SIZE);
    ui->label_Per->setVisible(false);
    ui->label_Plo->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_spinBox_valueChanged(int arg1)//изменили значение спинбокса
{
    ui->tableWidget->setRowCount(arg1);
}

int sign(double a)//опредеение знака
{
    if(a>0)
        return (1);
    else if(a<0)
        return (-1);
    else
        return (0);
}

void MainWindow::on_pushButton_res_clicked()//проверки и расчет результата
{
    int row = ui->tableWidget->rowCount();//строки
    int colum = ui->tableWidget->columnCount();//столбцы

    // объявление переменных
    double per, plo, ctorona, x0, x, y0, y;
    bool flag1, flag2, fl_1, fl_2;//флаг успешности

    plo = 0;
    per = 0;
    x0 = 0;
    x = 0;
    y0 = 0;
    y = 0;
    flag2 = false;
    fl_1 = false;
    fl_2 = false;

    x = last_coordinate_X(x);//координата "x" последней вершины
    y = last_coordinate_Y(y);//координата "y" последней вершины

    for (int i=0; i<row; i++)//перемещение по строкам
    {
        for (int j=0; j<colum; j++)//перемещение по столбцам
        {
            if (ui->tableWidget->item(i,j)!=nullptr)//проверка существования ячейки
            {
                if (j == 0)//столбец "x"
                {
                    x0 = x;//сохранение предыдущей координаты "x"
                    x = ui->tableWidget->item(i,j)->text().toDouble(&flag1);//присваиваем
                    if (flag1 && (fabs(isinf(x)-0) < 1e-10) && (fabs(isnan(x)-0) < 1e-10))//если в ячейке число
                    {
                        if (i==0)//сохраняем первую координату "x"
                        ui->tableWidget->item(i,j)->setBackground(Qt::white);//окрашиваем в белый
                    }
                    else if ((fabs(isinf(x)-0) > 1e-10)||(fabs(isnan(x)-0) > 1e-10))//в ячейке находится inf или nan
                    {
                        ui->tableWidget->item(i,j)->setBackground(Qt::red);//окрашиваем в красный
                        ui->label_Per->clear();//очистка периметра
                        ui->label_Plo->clear();//очистка площади
                        flag2 = true;
                    }
                    else//в ячейке мусор
                    {
                        ui->tableWidget->item(i,j)->setBackground(Qt::red);//окрашиваем в красный
                        ui->label_Per->clear();//очистка периметра
                        ui->label_Plo->clear();//очистка площади
                        flag2 = true;
                    }
                }
                else//если столбик "y"
                {
                    y0 = y;//сохранение предыдущей координаты "y"
                    y = ui->tableWidget->item(i,j)->text().toDouble(&flag1);//присваиваем
                    if (flag1 && (fabs(isinf(y)-0) < 1e-10) && (fabs(isnan(y)-0) < 1e-10))
                    {
                        if (i==0)//сохраняем первую координату "y"
                        ui->tableWidget->item(i,j)->setBackground(Qt::white);//окрашиваем в белый
                    }
                    else if ((fabs(isinf(y)-0) > 1e-10)||(fabs(isnan(x)-0) > 1e-10))//в ячейке находится inf или nan
                    {
                        ui->tableWidget->item(i,j)->setBackground(Qt::red);//окрашиваем в красный
                        ui->label_Per->clear();//очистка периметра
                        ui->label_Plo->clear();//очистка площади
                        flag2 = true;
                    }
                    else//в ячейке мусор
                    {
                        ui->tableWidget->item(i,j)->setBackground(Qt::red);//окрашиваем в красный
                        ui->label_Per->clear();//очистка периметра
                        ui->label_Plo->clear();//очистка площади
                        flag2 = true;
                    }
                }
            }
            else//не существует
            {
                //создаем
                QTableWidgetItem * ti; // создаем указатель на ячейку
                ti = new QTableWidgetItem; // выделяем память
                ui->tableWidget->setItem(i,j,ti); // помещаем ячейку в таблицу
                ui->tableWidget->item(i,j)->setBackground(Qt::red);
                ui->label_Per->clear();//очистка периметра
                ui->label_Plo->clear();//очистка площади
                flag2 = true;
            }
        }
            ctorona = sqrt((pow((x-x0),2) + pow((y-y0),2)));//нахождение стороны
            per = per + ctorona;//периметр
            plo = plo + ((x0 * y - x * y0)/2);//площадь
    }

double vx1, vx2, vx3, vx4, vy1, vy2, vy3, vy4, vx1_1, vx2_1, vx3_1, vx4_1, vy1_1, vy2_1, vy3_1, vy4_1;
double x1, x2, x3, y1, y2, y3;

int a1, a2, a3, a4;

x2 = 0;
y2 = 0;

//проверка на самопересекающийся многоугольник
for (int i=row-1; i>2; i--)
{
    x3=ui->tableWidget->item(i,0)->text().toDouble();
    y3=ui->tableWidget->item(i,1)->text().toDouble();
    if(!fl_2)
    {
        x2=ui->tableWidget->item(i-1,0)->text().toDouble();
        y2=ui->tableWidget->item(i-1,1)->text().toDouble();
    }

    for (int j=0;j<i-2;j++)
    {
        x0=ui->tableWidget->item(j,0)->text().toDouble();
        y0=ui->tableWidget->item(j,1)->text().toDouble();
        x1=ui->tableWidget->item(j+1,0)->text().toDouble();
        y1=ui->tableWidget->item(j+1,1)->text().toDouble();
        if(fl_2)
        {
            x0=ui->tableWidget->item(j+1,0)->text().toDouble();
            y0=ui->tableWidget->item(j+1,1)->text().toDouble();
            x1=ui->tableWidget->item(j+2,0)->text().toDouble();
            y1=ui->tableWidget->item(j+2,1)->text().toDouble();
        }

        vx1=x0-x3;
        vy1=y0-y3;
        vx2=x1-x3;
        vy2=y1-y3;
        vx3=x0-x2;
        vy3=y0-y2;
        vx4=x1-x2;
        vy4=y1-y2;

        //векторы
        vx1_1=x3-x0;
        vy1_1=y3-y0;
        vx2_1=x3-x1;
        vy2_1=y3-y1;
        vx3_1=x2-x0;
        vy3_1=y2-y0;
        vx4_1=x2-x1;
        vy4_1=y2-y1;

        a1=sign(vx2*vy1-vy2*vx1);
        a2=sign(vx4*vy3-vy4*vx3);
        a3=sign(vx1_1*vy3_1-vy1_1*vx3_1);
        a4=sign(vx2_1*vy4_1-vy2_1*vx4_1);

        if(a1!=a2&&a3!=a4&&(a1!=0&&a2!=0&&a3!=0&&a4!=0))//срвнение знака
            fl_1=true;
    }
    if (i==3&&!fl_1&&!fl_2)
    {
        i=row;
        x2=ui->tableWidget->item(0,0)->text().toDouble();
        y2=ui->tableWidget->item(0,1)->text().toDouble();
        fl_2=true;
    }
}
    if (flag2)//ошибка
    {
        ui->label_Per->setVisible(false);
        ui->label_Plo->setVisible(false);
    }
    else if(fl_1)//многоугольник самопересекающийся
    {
        ui->label_Per->setVisible(true);
        ui->label_Plo->setVisible(true);
        ui->label_Plo->setText("многоугольник самопересекающийся");
        ui->label_Per->setNum(per);//вывод результата периметра
    }
    else if((fabs(per-0) < 1e-10)||(fabs(plo-0) < 1e-10))//многоугольник лежащий на одной прямой
    {
        ui->label_Per->setVisible(true);
        ui->label_Plo->setVisible(true);
        ui->label_Plo->setText("многоугольник лежащий на одной прямой");
        ui->label_Per->setNum(per);//вывод результата периметра
    }
    else
    {
        ui->label_Per->setVisible(true);
        ui->label_Plo->setVisible(true);
        ui->label_Per->setNum(per);//вывод результата периметра
        ui->label_Plo->setNum(fabs(plo));//вывод результата площади
    }
    no_auto_change=true;

}

double MainWindow::last_coordinate_X(double x)//координата "x" вершины
{
    int row = ui->tableWidget->rowCount();//строки
    bool flag;

    if (ui->tableWidget->item(row-1,0)!=nullptr)//проверка на существование ячейки
    {
        x = ui->tableWidget->item(row-1,0)->text().toDouble(&flag);//достаем число из последней ячейки столбца "х"
        if (flag && (fabs(isinf(x)-0) < 1e-10))//в ячейке число
            ui->tableWidget->item(row-1,0)->setBackground(Qt::white);
        else//в ячейке мусор
        {
            ui->tableWidget->item(row-1,0)->setBackground(Qt::red);
            ui->label_Per->clear();//очистка периметра
            ui->label_Plo->clear();//очистка площади
        }
    }
    else
    {
        QTableWidgetItem * ti;//создаем указатель на ячейку
        ti = new QTableWidgetItem;//выделяем память
        ui->tableWidget->setItem(row-1,0,ti);//помещаем ячейку в таблицу
        ui->tableWidget->item(row-1,0)->setBackground(Qt::red);
        ui->label_Per->clear();//очистка периметра
        ui->label_Plo->clear();//очистка площади
    }
    return x;
}

double MainWindow::last_coordinate_Y(double y)//координата "y" вершины
{
    int row = ui->tableWidget->rowCount();//количество строк
    bool flag;

    if (ui->tableWidget->item(row-1,1)!=nullptr)//проверка на существование ячейки
    {
        y = ui->tableWidget->item(row-1,1)->text().toDouble(&flag);//достаем число из последней ячейки столбца Y
        if (flag && (fabs(isinf(y)-0) < 1e-10))//в ячейке число
            ui->tableWidget->item(row-1,1)->setBackground(Qt::white);
        else//в ячейке мусор
        {
            ui->tableWidget->item(row-1,1)->setBackground(Qt::red);
            ui->label_Per->clear();//очистка периметра
            ui->label_Plo->clear();//очистка площади
            ui->label_Per->setVisible(false);
            ui->label_Plo->setVisible(false);
        }
    }
    else
    {
        QTableWidgetItem * ti;//создаем указатель на ячейку
        ti = new QTableWidgetItem;//выделяем память
        ui->tableWidget->setItem(row-1,1,ti);//помещаем ячейку в таблицу
        QBrush br;
        br.setColor(Qt::red);
        br.setStyle(Qt::DiagCrossPattern);
        ui->tableWidget->item(row-1,1)->setBackground(Qt::red);
        ui->label_Per->clear();//очистка периметра
        ui->label_Plo->clear();//очистка площади
    }
    return y;
}

void MainWindow::on_tableWidget_cellChanged(int row, int column)//изменения ячейки
{
    if (no_auto_change)
    {
        bool flag;
        ui->tableWidget->item(row,column)->text().toInt(&flag);
        if (flag)
            ui->tableWidget->item(row,column)->setBackground(Qt::white);//окраска в белый
        else
        {
            QBrush br;
            br.setColor(Qt::red);
            br.setStyle(Qt::DiagCrossPattern);
            ui->tableWidget->item(row,column)->setBackground(Qt::red);
            ui->label_Per->clear();//очистка периметра
            ui->label_Plo->clear();//очистка площади
        }
    }
}

void MainWindow::on_pushButton_clear_clicked()//очистка
{
    ui->tableWidget->clearContents();//очистка таблицы
    ui->label_Per->clear();//очистка периметра
    ui->label_Plo->clear();//очистка площади
}

void MainWindow::on_Random_clicked()//заполнение
{
    no_auto_change=false;
    int row=ui->tableWidget->rowCount();
    int colum=ui->tableWidget->columnCount();

    int value;

    for (int i=0;i<row;i++)
        for (int j=0;j<colum;j++)
        {
            if (ui->tableWidget->item(i,j)==nullptr)
            {
                QTableWidgetItem * ti; //создали указатель
                ti =  new QTableWidgetItem(); //выделяем память
                ui->tableWidget->setItem(i,j,ti); //помещаем ячейку в таблицу
            }
            QBrush br;
            br.setColor(Qt::white);
            br.setStyle(Qt::DiagCrossPattern);
            ui->tableWidget->item(i,j)->setBackground(Qt::white);

            value=rand()%201-100; // от -100 до 100
            ui->tableWidget->item(i,j)->setText(QString::number(value));
        }
    no_auto_change=true;
}

