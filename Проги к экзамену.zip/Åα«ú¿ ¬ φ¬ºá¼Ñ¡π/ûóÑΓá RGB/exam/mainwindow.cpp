#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMessageBox"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tableWidget->setRowCount(1);
    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList()<<"R"<<"G"<<"B"<<"Color");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()//RGB
{
    int R=0;
    int G=0;
    int B=0;

    bool flagR,flagG,flagB;

   QTableWidgetItem *item=ui->tableWidget->item(0,3);
   if(item == nullptr)
   {
       item=new QTableWidgetItem;
       ui->tableWidget->setItem(0,3,item);
   }
   item->setText(" ");


   QTableWidgetItem *item_r = ui->tableWidget->item(0,0);
   QTableWidgetItem *item_g = ui->tableWidget->item(0,1);
   QTableWidgetItem *item_b = ui->tableWidget->item(0,2);

   if(item_r==nullptr)
   {
       item->setBackground(Qt::white);
       QMessageBox::information(this, "Ошибка","НЕ введенно значение R");
       return;
   }
   if(item_g==nullptr)
   {
       item->setBackground(Qt::white);
       QMessageBox::information(this, "Ошибка","НЕ введенно значение G");
       return;
   }
   if(item_b==nullptr)
   {
       item->setBackground(Qt::white);
       QMessageBox::information(this, "Ошибка","НЕ введенно значение B");
       return;
   }
   R=ui->tableWidget->item(0,0)->text().toInt(&flagR);
   G=ui->tableWidget->item(0,1)->text().toInt(&flagG);
   B=ui->tableWidget->item(0,2)->text().toInt(&flagB);

   if(!flagR)
   {
       item->setBackground(Qt::white);
       QMessageBox::information(this, "Ошибка","Введенно некорректное значение R");
       return;
   }
   if(!flagG)
   {
       item->setBackground(Qt::white);
       QMessageBox::information(this, "Ошибка","Введенно некорректное значение G");
       return;
   }
   if(!flagB)
   {
       item->setBackground(Qt::white);
       QMessageBox::information(this, "Ошибка","Введенно некорректное значение B");
       return;
   }
   if(R<0||R>255)
   {
       item->setBackground(Qt::white);
       QMessageBox::information(this, "Ошибка","Диапазон чисел R равняется от 0 и до 255");
       return;
   }
   if(G<0||G>255)
   {
       item->setBackground(Qt::white);
       QMessageBox::information(this, "Ошибка","Диапазон чисел G равняется от 0 и до 255");
       return;
   }
   if(B<0||B>255)
   {
       item->setBackground(Qt::white);
       QMessageBox::information(this, "Ошибка","Диапазон чисел B равняется от 0 и до 255");
       return;
   }
   item->setBackground(QColor(R,G,B));


}

void MainWindow::on_pushButton_2_clicked()//что введено в ячейке
{
    QString str = ui->tableWidget->item(0,0)->text();\

    QString type= "Пусто";
    bool flagDouble;
    str.toDouble(&flagDouble);
    if(flagDouble)
    {
        type="Вещественное";
    }

    bool flagInt;
    str.toInt(&flagInt);
    if(flagInt)
    {
        type="Целое";
    }

    if(!flagInt&& !flagDouble)
    {
      if(str == "?")
      {
          type="Вопрос";
      }
      else if(str.size()==1)
      {
          if((str >="A"&& str<="Z")||(str>="a"&& str<="z") )
          {
              type="БУКВА";
          }
          else
          {
              type="Символ";
          }
      }
      else
      {
          type="Строка";
      }
    }

    QTableWidgetItem *item=ui->tableWidget->item(0,3);
    if(item == nullptr)
    {
        item=new QTableWidgetItem;
        ui->tableWidget->setItem(0,3,item);
    }
    item->setText(type);
}
