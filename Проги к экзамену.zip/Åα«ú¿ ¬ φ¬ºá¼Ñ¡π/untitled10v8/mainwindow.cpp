#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <math.h>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushBatton_clicked()
{
    bool fl;
    QString str = ui->lineEdit->text();
    int a = str.toInt(&fl);

    if ((a>0) && !(isinf(a)))
        ui->lable->setText(QString::number(a, 8));
    else if ((a<0) && !(isinf(a)))
    {
        ui->lable->setText("-" + QString::number(a, 8));
    }
    else
        ui->lable->setText("Ошибка");
}
