
int factorial(int N)  //факториал
{
    if(N==0) return 1; // Если factorial(0), то возвращаем 1
    if(N==1) return 1; // Если factorial(1), то возвращаем 1
    return N*factorial(N-1); // А если нет, то возвращаем значение N*factorial(N-1)
}

int binnnn()          //из 10 в 2
{
int dec, bin, mod;

    cin >> dec;

    unsigned int  dec;
    for(int i=0;i<32;i++,dec<<=1) putchar(48+(dec>>31));
}

int main()            //из 10 в 16
{
    string s;
    int a;
    cin >> a;
    char m[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
    while ((a != 0)
    {
      s = m[a % 16] + s;
      a/=16;
    }
    cout<<DecHex(s);
    return 0;
}

int findpopular()    //самый часто встречаемый элемент
{
    int mass[N]; //заполняем массив случайными значениями от 0 до 99
    for (int i = 0; i < N; i++) mass[i] = rand()%100;

    int maxcount(1), nn(-1); //перебираем все элементы массива
    for (int i = 0; i < N; i++)
    {
        int count(0); //перебираем все элементы от i до конца
        for (int j = i; j < N; j++) //если элемент i совпадает с одним из последующих (j), то увеличиваем число
            if (mass[i] == mass[j])
                count++;
        if (maxcount < count) //если число больше ранее сохраненного - перезаписываем
        {
            maxcount = count;
            nn = i;
        }
    }
    return mass[nn];
}

int findrare()       //самый редко встречаемый элемент
{
    int mass[N]; //заполняем массив случайными значениями от 0 до 99
    for (int i = 0; i < N; i++) mass[i] = rand()%100;

    int mincount(1000), nn(-1); //перебираем все элементы массива
    for (int i = 0; i < N; i++)
    {
        int count(1000); //перебираем все элементы от i до конца
        for (int j = i; j < N; j++) //если элемент i совпадает с одним из последующих (j), то увеличиваем число
            if (mass[i] == mass[j])
                count++;
        if (mincount > count) //если число больше ранее сохраненного - перезаписываем
        {
            mincount = count;
            nn = i;
        }
    }
    return mass[nn];
}

int sumdiv2()        //сумма элементов с четным индексом
{
  int *mas, sum;
  sum = 0;
  mas = new int[n];
  for (int i = 0; i < N; i++) mass[i] = rand()%100;
  for (unsigned int i = 0; i < N; i += 2) sum += mas[i];
  return sum;
}

int summod2()        //сумма элементов с нечетным индексом
{
  int *mas, sum;
  sum = 0;
  mas = new int[n];
  for (int i = 0; i < N; i++) mass[i] = rand()%100;
  for (unsigned int i = 1; i < N; i += 2) sum += mas[i];
  return sum;
}

long multminusarr()  //произведение всех отрицательных
{
    long sum = 0;
    for (unsigned int i = 0; i < N; i++) {
        if (ary[i] < 0) {
            sum *= ary[i];
        }
    }
}


//из 16 в 10
bool fl=false;
int value = ui->lineEdit->text().toInt(&fl,16);

QString nexValue;
nexValue.setNum(value,10);

ui->lable->setText(nextValue);
//















