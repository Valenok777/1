#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <math.h>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    no_auto_change = true;
    ui->spinBox->setMaximum(MAX_MAS_SIZE);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_tableWidget_cellChanged(int row)
{
    if(no_auto_change)
    {

        bool flag;
        double x = ui->tableWidget->item(row,0)->text().toDouble(&flag);

        if (flag && (fabs(isinf(x)-0) < 1e-7) && (fabs(isnan(x)-0) < 1e-7))
        {
            ui->tableWidget->item(row,0)->setBackground(Qt::white);
            ui->label->setVisible(false);
        }
        else
        {
            ui->tableWidget->item(row,0)->setBackground(Qt::red);
            ui->label->setVisible(false);
        }
    }
}

void MainWindow::on_pushButton_clicked()
{
    no_auto_change = false;
    int row = ui->tableWidget->rowCount();
    int rub = -1;
    bool flag; // признак успешной конвертации ячейки
    bool gl_flag = true; // признак успешного формирования массива из таблицы

    // заполнение массива + проверка на число
    for (int i=0; i<row; i++)
        if (ui->tableWidget->item(i,0)==nullptr)
        {
            gl_flag=false; // нет ячейки
            QTableWidgetItem * ti; // создаем указатель на ячейку
            ti = new QTableWidgetItem; // выделяем память
            ui->tableWidget->setItem(i,0,ti); // помещаем ячейку в таблицу
            ui->tableWidget->item(i,0)->setBackground(Qt::red);
            if (rub == -1)
                rub = i;
            ui->label->setVisible(false);
        }
        else
        {
            mas_table[i] = ui->tableWidget->item(i,0)->text().toDouble(&flag);
            if (flag && (fabs(isinf(mas_table[i])-0) < 1e-7) && (fabs(isnan(mas_table[i])-0) < 1e-7))
                ui->tableWidget->item(i,0)->setBackground(Qt::white);
            else
            {
                ui->tableWidget->item(i,0)->setBackground(Qt::red);
                gl_flag=false; // есть ячейка с ошибкой
                if (rub == -1)
                    rub = i;
                ui->label->setVisible(false);
            }
        }

    if (gl_flag)//самое маленькое положительное число
    {
        double c=0;
        for(int i=0;i<row;i+=2)
        {
            c+=mas_table[i];   //c=c+ui->tableWidget->item(i,0)->text().toDouble(&flag);
        }
        ui->label->setVisible(true);
        ui->label->setNum(c);
    }
}


void MainWindow::on_spinBox_valueChanged(int arg1)
{
    ui->tableWidget->setRowCount(arg1);
}

