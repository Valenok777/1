#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMessageBox>
#define MAX_MAS_SIZE 200 // максимальный размер массива

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();


private slots:
    void on_pushButton_clicked();
    void on_tableWidget_cellChanged(int row);

    void on_spinBox_valueChanged(int arg1);

private:
    Ui::MainWindow *ui;
    bool no_auto_change; // признак НЕ автоматической проверки (ручной ввод)
    double mas_table[MAX_MAS_SIZE]; // У нас в практике будет одномерный массив
};
#endif // MAINWINDOW_H
