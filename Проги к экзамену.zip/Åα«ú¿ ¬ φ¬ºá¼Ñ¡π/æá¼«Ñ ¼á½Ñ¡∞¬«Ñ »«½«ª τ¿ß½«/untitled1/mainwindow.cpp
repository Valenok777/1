#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <math.h>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    no_auto_change = true;
    ui->spinBox->setMaximum(MAX_MAS_SIZE);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_tableWidget_cellChanged(int row)
{
    if(no_auto_change)
    {

        bool flag;
        double x = ui->tableWidget->item(row,0)->text().toDouble(&flag);

        if (flag && (fabs(isinf(x)-0) < 1e-7) && (fabs(isnan(x)-0) < 1e-7))
        {
            ui->tableWidget->item(row,0)->setBackground(Qt::white);
            ui->label->setVisible(false);
        }
        else
        {
            ui->tableWidget->item(row,0)->setBackground(Qt::red);
            ui->label->setVisible(false);
        }
    }
}

void MainWindow::on_pushButton_clicked()
{
    no_auto_change = false;
    int row = ui->tableWidget->rowCount();
    int rub = -1;
    bool flag; // признак успешной конвертации ячейки
    bool gl_flag = true; // признак успешного формирования массива из таблицы

    // заполнение массива + проверка на число
    for (int i=0; i<row; i++)
        if (ui->tableWidget->item(i,0)==nullptr)
        {
            gl_flag=false; // нет ячейки
            QTableWidgetItem * ti; // создаем указатель на ячейку
            ti = new QTableWidgetItem; // выделяем память
            ui->tableWidget->setItem(i,0,ti); // помещаем ячейку в таблицу
            ui->tableWidget->item(i,0)->setBackground(Qt::red);
            if (rub == -1)
                rub = i;
        }
        else
        {
            mas_table[i] = ui->tableWidget->item(i,0)->text().toDouble(&flag);
            if (flag && (fabs(isinf(mas_table[i])-0) < 1e-7) && (fabs(isnan(mas_table[i])-0) < 1e-7))
                ui->tableWidget->item(i,0)->setBackground(Qt::white);
            else
            {
                ui->tableWidget->item(i,0)->setBackground(Qt::red);
                gl_flag=false; // есть ячейка с ошибкой
                if (rub == -1)
                    rub = i;
            }
        }

    if (gl_flag)
    { // массив сформированн корректно
        // сортировка расчесткой
        int step = row;
        int i = 0;
        double t = 0;
        int factor = 2; // фактор уменьшения
        bool fl = true;
        while (step > 1 || fl)
        {
            if (step>1)
                step = step/factor;
            fl = false;
            i = 0;
            while (i + step < row)
            {
                if (mas_table[i]>mas_table[i+step])
                {
                    t = mas_table[i];
                    mas_table[i] = mas_table[i+step];
                    mas_table[i+step] = t;
                    fl = true;
                }
                i+=1;
            }
        }

        // вывод результатов в таблицу (без проверок, так как gl_flag = true)
        for (int i=0; i<row; i++)
            ui->tableWidget->item(i,0)->setText(QString::number(mas_table[i]));
    }
    else
        QMessageBox::information(this, "Ошибка", "Таблица содержит ячейки с некорректным значением.", QMessageBox::Ok);

    if (gl_flag)//самое маленькое положительное число
    {
        int sum=0;
        for(int i=0;i<row;i++)
        {
            if(mas_table[i]>0)
            {
                if(sum==0  ||  mas_table[i]<sum )
                    sum=mas_table[i];
            }
            ui->label->setVisible(true);
            ui->label->setNum(sum);
        }
            //return sum; // если нет положительных, то вернется ноль
    }
}


void MainWindow::on_spinBox_valueChanged(int arg1)
{
    ui->tableWidget->setRowCount(arg1);
}

