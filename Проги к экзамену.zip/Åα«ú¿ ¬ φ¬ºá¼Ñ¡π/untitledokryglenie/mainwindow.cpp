#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    ui->label->clear();
    int a = ui->spinBox->value();
    bool flag;
    double chislo = ui->lineEdit->text().toDouble(&flag);
    if(flag) // задаем формулу число переменная переменная спинбокса
    {
        QString lable;
        lable = QString::number(chislo, 'f', a);
        ui->lineEdit->setText(lable);
    }
    else
    {
        ui->label->setText("Вы ввели некоректное значение");
    }
}

