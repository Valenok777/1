#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMessageBox"
#include "QDebug"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tableWidget->setColumnCount(1);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_spinBox_valueChanged(int arg1)
{
    ui->tableWidget->setRowCount(arg1);

    for (int i=0;i<arg1;i++)
    {
        QTableWidgetItem *item=ui->tableWidget->item(i,0);
        if(item==nullptr)
        {
            item=new QTableWidgetItem;
            item->setText("0");
            ui->tableWidget->setItem(i,0,item);
        }
    }
}

void MainWindow::on_pushButton_clicked()
{
    int rows=ui->tableWidget->rowCount();

    int count = 0;
    for (int i=0;i<rows;i++)
    {
      int val=ui->tableWidget->item(i,0)->text().toInt();

      if(val%2==0 && val>=0 && val<=100)
      {
          count++;
      }

    }
    QMessageBox::information(this,"Ошибка","Кол-во четных чисел : " + QString::number(count));
}

void MainWindow::on_pushButton_2_clicked()
{
    int rows=ui->tableWidget->rowCount();

    int count = 0;
    for (int i=0;i<rows;i++)
    {
      int val=ui->tableWidget->item(i,0)->text().toInt();

      if(val>=0 )
      {
          count++;
      }

    }
    QMessageBox::information(this,"Ошибка","Кол-во положительных чисел : " + QString::number(count));
}

void MainWindow::on_pushButton_3_clicked()
{
    int rows=ui->tableWidget->rowCount();

    int summa = 0;
    for (int i=0;i<rows;i++)
    {
      int val=ui->tableWidget->item(i,0)->text().toInt();

      if(val>=0 )
      {
          summa +=val;
      }

    }
    QMessageBox::information(this,"Ошибка","Сумма положительных чисел : " + QString::number(summa));
}

void MainWindow::on_pushButton_4_clicked()//СОРТИРОВКА ПУЗЫРЬКОМ
{
    int rows=ui->tableWidget->rowCount();
    int mas[1000];
    //считываем
    for (int i=0;i<rows;i++)
    {
        mas[i]= ui->tableWidget->item(i,0)->text().toInt();
        
    }
    
    for (int i=0;i<rows ;i++ )
    {
        for (int j=0;j<rows-1 ;j++ )
        {
            if(mas[j]>mas[j+1])
            {
                int b=mas[j];// создаем доп переменную
                mas[j]=mas[j+1];// меняем местами
                mas[j+1]=b;//значения элементотв
            }
        }

    }
    for (int i=0;i<rows;i++)
    {
        ui->tableWidget->item(i,0)->setText(QString::number(mas[i]));//вывожу значение в таблицу
    }
}




void MainWindow::on_pushButton_5_clicked()
{
    bool ok;
    QString str="С";
    int val10=str.toInt(&ok,16);

    QString val2;
    val2.setNum(13,2);

    int sourcess=ui->lineEdit_source->text().toInt();
    int nextss=ui->lineEdit_next->text().toInt();
    bool flag=false;
    int value=ui->lineEdit_val->text().toInt(&flag,sourcess);

    QString nextvalue;
    nextvalue.setNum(value,nextss);
    ui->label->setText(nextvalue);

}
