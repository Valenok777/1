#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTableWidget>
#include <QMessageBox>
#include <search.h>
#include "math.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_randomcell_clicked();

    bool isCorrectValues(); // функция проверяющая корректные ли значения введены в таблицу
    bool isCorrectItem(QTableWidgetItem *item);//возвращает корректное ли значение в item
    void readMassive();
    void writeMassive();
    void QsortRecursive(double *mas, int size);//функция для быстрой сортировки
    bool isCorrect();//возвращает значение корректности сортировки массива
    void shuffle();
    void bogoSort();





    void on_pushButton_addcell_clicked();

    void on_pushButton_delcell_clicked();

    void on_pushButton_randfilling_clicked();

    void on_spinBox_valueChanged(int arg1);

    void on_pushButton_min_clicked();

    void on_pushButton_avg_clicked();

    void on_pushButton_max_clicked();

//    void on_tableWidget_itemChanged(QTableWidgetItem *item);

    void on_tableWidget_cellChanged(int row, int column);

    void on_pushButton_clicked();

    void on_pushButton_comb_clicked();

    void on_pushButton_bubble_clicked();

    void on_pushButton_fast_clicked();

    void on_pushButton_monkey_clicked();

    void on_pushButton_gnom_clicked();

    void on_pushButton_search_clicked();

    void on_pushButton_deldublicate_clicked();

private:
    Ui::MainWindow *ui;
    double *mas=nullptr;
    int size=0;
    bool allowchanged;
};

#endif // MAINWINDOW_H
