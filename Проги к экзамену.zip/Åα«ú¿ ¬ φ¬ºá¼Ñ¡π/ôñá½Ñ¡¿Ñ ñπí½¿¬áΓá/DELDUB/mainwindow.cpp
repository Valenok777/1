#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tableWidget->setColumnCount(1);//устанавливаем в таблицу 1 столбец
    ui->tableWidget->setRowCount(1);//устанавливаем в таблицу 1 строчку
    ui->spinBox->setValue(1);
    allowchanged=true;
    mas=nullptr;
    
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_randomcell_clicked()//заполняем таблицу рандомным количеством строчек
{
    
    ui->label_min->clear();
    ui->label_max->clear();
    ui->label_avg->clear();
    ui->label_numberinclude->clear();
    ui->textEdit_nubmercell->clear();
    ui->lineEdit_desiredvalue->clear();
    ui->tableWidget->clear();
    
    int rows = 1 + rand()%1000000;
    ui->tableWidget->setRowCount(rows);
    ui->spinBox->setValue(rows);
    
}

void MainWindow::on_pushButton_addcell_clicked()//добавляем ячейку
{
    ui->spinBox->setValue(ui->spinBox->value()+1);
}

void MainWindow::on_pushButton_delcell_clicked()//удаляем ячейку
{
    ui->spinBox->setValue(ui->spinBox->value()-1);
}

void MainWindow::on_pushButton_randfilling_clicked()//рандомное заполнение чисел в строчках
{
    ui->label_min->clear();
    ui->label_max->clear();
    ui->label_avg->clear();
    ui->label_numberinclude->clear();
    ui->textEdit_nubmercell->clear();
    ui->lineEdit_desiredvalue->clear();
    
    int rows=ui->tableWidget->rowCount();
    if(rows>49999)
    {
        QMessageBox::warning(this,"Предупреждение","Возможно программа будет тормозить, потому что слишком много ячеек");
    }
    for(int i=0; i<rows; i++)
    {
        QTableWidgetItem* item = ui->tableWidget->item(i,0);
        if(item == nullptr)
        {
            item = new QTableWidgetItem;
            ui->tableWidget->setItem(i,0,item);
        }
        
        int val = rand()%1000;
        QString text;
        text.setNum(val);
        item->setText(text);
        
        //            ui->label_rand->setText(QString::number(i+1) + " / " + QString::number(rows));//выводим в label текущие кол-во заполненых значений
        //            QApplication::processEvents();// не даем проге зависнуть
    }
    if(rows==0)
    {
        QMessageBox::information(this,"Ошибка","Недостаточно строк!");
        return;
    }
}

void MainWindow::on_spinBox_valueChanged(int arg1)//меняем значение в спинбоксе
{
    ui->tableWidget->setRowCount(arg1);
    ui->label_avg->clear();
    ui->label_min->clear();
    ui->label_max->clear();

}

void MainWindow::on_pushButton_min_clicked()//минимальное значение в строчках
{
    int rows=ui->tableWidget->rowCount();
    bool correct = isCorrectValues();//функция проверки
    if(size>199999)
    {
        QMessageBox::warning(this,"Предупреждение","Возможно программа будет тормозить, потому что слишком много ячеек");
    }
    if(!correct)//если есть ошибка
    {
        ui->label_min->clear();
        ui->label_max->clear();
        ui->label_avg->clear();
        ui->label_numberinclude->clear();
        ui->textEdit_nubmercell->clear();
        
        QMessageBox::information(this,"Ошибка","Ошибка в значении");
        return;
    }
    else //если нет ошибок
    {
        double min = ui->tableWidget->item(0,0)->text().toDouble();
        for(int i=1; i<rows; i++)
        {
            double val = ui->tableWidget->item(i,0)->text().toDouble();
            if(val<min)
            {
                min=val;
            }
        }
        ui->label_min->setNum(min);
    }
}

void MainWindow::on_pushButton_avg_clicked()//среднее значение
{
    int rows=ui->tableWidget->rowCount();
    bool correct = isCorrectValues();//функция проверки
    
    if(size>199999)
    {
        QMessageBox::warning(this,"Предупреждение","Возможно программа будет тормозить, потому что слишком много ячеек");
    }
    if(!correct)
    {
        ui->label_min->clear();
        ui->label_max->clear();
        ui->label_avg->clear();
        ui->label_numberinclude->clear();
        ui->textEdit_nubmercell->clear();
        QMessageBox::information(this,"Ошибка","Ошибка в значении");
        return;
    }
    else //если нет ошибок
    {
        double avg = ui->tableWidget->item(0,0)->text().toDouble();
        for(int i=1; i<rows; i++)
        {
            double val = ui->tableWidget->item(i,0)->text().toDouble();
            avg+=val;
        }
        avg=avg/static_cast<double>(rows);
        ui->label_avg->setNum(avg);
    }
}

void MainWindow::on_pushButton_max_clicked()//максимальное значение в строчках
{
    int rows=ui->tableWidget->rowCount();
    bool correct = isCorrectValues();//функция проверки
    if(size>199999)
    {
        QMessageBox::warning(this,"Предупреждение","Возможно программа будет тормозить, потому что слишком много ячеек");
    }
    if(!correct)
    {
        ui->label_min->clear();
        ui->label_max->clear();
        ui->label_avg->clear();
        ui->label_numberinclude->clear();
        ui->textEdit_nubmercell->clear();
        
        QMessageBox::information(this,"Ошибка","Ошибка в значении");
        return;
    }
    else //если нет ошибок
    {
        double max = ui->tableWidget->item(0,0)->text().toDouble();
        for(int i=1; i<rows; i++)
        {
            double val = ui->tableWidget->item(i,0)->text().toDouble();
            if(val>max)
            {
                max=val;
            }
        }
        ui->label_max->setNum(max);
    }
}
bool MainWindow::isCorrectValues()//корректное значение
{
    int rows=ui->tableWidget->rowCount();
    if(rows==0)
    {
        //QMessageBox::information(this,"Ошибка","Недостаточно строк");
        return false;
    }
    QTableWidgetItem* itemWithError = nullptr;
    for (int i=0; i<rows; i++)
    {
        QTableWidgetItem*item = ui->tableWidget->item(i,0);
        if(item == nullptr)
        {
            item = new QTableWidgetItem;
            ui->tableWidget->setItem(i,0,item);
            item->setBackground(QBrush(Qt::red));
            if(itemWithError==nullptr)
            {
                itemWithError=item;
            }
        }
        else
        {
            bool correctItem= isCorrectItem(item);
            if(!correctItem)
            {
                if(itemWithError==nullptr)
                {
                    itemWithError=item;
                }
            }
        }
        
    }
    if(itemWithError!=nullptr)//если есть ошибки
    {
        ui->tableWidget->scrollToItem(itemWithError);
        return false;
    }
    return true;
}
bool MainWindow::isCorrectItem(QTableWidgetItem *item)//корректное значение в ячейках
{
    if(item->text()=="")
    {
        item->setBackground(QBrush(Qt::red));
        return false;
    }
    else
    {
        bool flag = false;
        double val = item->text().toDouble(&flag);
        if(!flag ||qIsInf(val) ||qIsNaN(val))
        {
            item->setBackground(QBrush(Qt::red));
            return false;
        }
        else
        {
            item->setBackground(QBrush(Qt::white));
            return true;
        }
    }
}


//void MainWindow::on_tableWidget_itemChanged(QTableWidgetItem *item)//проверка значений в ячейке
//{
//    if(allowchanged)
//    {

//        isCorrectItem(item);
//        ui->label_avg->clear();
//        ui->label_min->clear();
//        ui->label_max->clear();

//        ui->label_numberinclude->clear();
//        ui->textEdit_nubmercell->clear();

//        for(int i=0; i<ui->tableWidget->rowCount(); i++)
//        {
//            QTableWidgetItem *checkItem =ui->tableWidget->item(i,0);
//            if(checkItem!= item &&checkItem!=nullptr)// нужно  чтобы не вызвалась проверка самого себя , и не пустой
//            {
//                isCorrectItem(checkItem);
//            }


//        }

//    }
//}

void MainWindow::on_tableWidget_cellChanged(int row, int column)//проверка значений в ячейке и перекрашивание
{


    if(allowchanged)
    {
        ui->label_avg->clear();
        ui->label_min->clear();
        ui->label_max->clear();


        isCorrectItem(ui->tableWidget->item(row,column));


        bool flag;//переменная для проверки успешности
        
        double val = ui->tableWidget->item(row,0)->text().toDouble(&flag);
        if (flag)//если успешно
        {
            if(qIsInf(val)||qIsNaN(val))//проверка на введение inf || nan
            {
                ui->tableWidget->item(row,0)->setBackground(Qt::red);
                return;
            }
            else{
                ui->tableWidget->item(row,0)->setBackground(Qt::white);
                return;
            }

        }
        else//не успешно
        {
            ui->tableWidget->item(row,0)->setBackground(Qt::red);
        }

    }

}


void MainWindow::on_pushButton_clicked()// очистка
{
    ui->tableWidget->clear();
    ui->label_avg->clear();
    ui->label_min->clear();
    ui->label_max->clear();
    ui->spinBox->setValue(1);
    ui->lineEdit_desiredvalue->clear();
    ui->textEdit_nubmercell->clear();
    ui->label_numberinclude->clear();
    delete [] mas;
    mas = nullptr;
    allowchanged = true;//флаг ручного управления отрицательный
}

void MainWindow::readMassive()//функция для заполнения массива из таблицы
{
    size=ui->tableWidget->rowCount();//получаем кол-во элементов
    if(mas!=nullptr)//если память под массив уже была выделена
    {
        delete [] mas;// удаляем старые данные
        mas=nullptr;
    }
    mas = new double[size];//динамически выделяем память под новый массив
    for (int i=0;i<size;i++)
    {
        mas[i]=ui->tableWidget->item(i,0)->text().toDouble();// заполняем массив
    }
}

void MainWindow::writeMassive()//функция для вывода отсортированного массива
{
    for (int i=0;i<size;i++)
    {
        QString Itemtext;
        Itemtext.setNum(mas[i]);
        ui->tableWidget->item(i,0)->setText(Itemtext);//вывожу значение в таблицу
    }
}

void MainWindow::on_pushButton_comb_clicked()// сортировка расчесткой
{
    allowchanged=false;
    ui->label_numberinclude->clear();
    ui->textEdit_nubmercell->clear();
    
    int rows=ui->tableWidget->rowCount();
    if(rows>99999)
    {
        QMessageBox::warning(this,"Предупреждение","Возможно программа будет тормозить, потому что слишком много ячеек");
    }
    
    bool correct = isCorrectValues();//функция проверки
    if(!correct)
    {
        ui->label_min->clear();
        ui->label_max->clear();
        ui->label_avg->clear();
        ui->label_numberinclude->clear();
        ui->textEdit_nubmercell->clear();
        
        QMessageBox::information(this,"Ошибка","Некорректные данные");
        allowchanged=true;
        return;
    }
    readMassive();//получаем массив из таблицы
    
    //cкопированный код сортировки
    
    double factor=1.2473309;// фактор уменьшения
    int step = size-1;// шаг сортировки
    
    //Последняя итерация цикла, когда step==1 эквивалентна одномк проходу сортировки пузырьком
    while (step>=1)
    {
        for (int i=0;i+step<size;i++)
        {
            if(mas[i]>mas[i+step])
            {
                std::swap(mas[i],mas[i+step]);
            }
        }
        step /= factor;
    }
    writeMassive();
    allowchanged=true;
}

void MainWindow::on_pushButton_bubble_clicked()//сортировка пузырьком
{

    allowchanged=false;

    if(size>99999)
    {
        QMessageBox::warning(this,"Предупреждение","Возможно программа будет тормозить, потому что слишком много ячеек");
    }
    bool correct = isCorrectValues();//функция проверки
    if(!correct)
    {
        ui->label_min->clear();
        ui->label_max->clear();
        ui->label_avg->clear();
        ui->label_numberinclude->clear();
        ui->textEdit_nubmercell->clear();
        
        QMessageBox::information(this,"Ошибка","Некорректные данные");
        allowchanged=true;
        return;
    }
    readMassive();// получаем массив из таблицы
    //скопированный код сортировки
    
    for (int i=0;i<size ;i++ )
    {
        for (int j=0;j<size-1 ;j++ )
        {
            if(mas[j]>mas[j+1])
            {
                double b=mas[j];// создаем доп переменную
                mas[j]=mas[j+1];// меняем местами
                mas[j+1]=b;//значения элементотв
            }
        }
    }
    writeMassive();//выводим отсортированный массив
    allowchanged=true;
    
}
void MainWindow::QsortRecursive(double *mas, int size)//функця для быстрой сортировки
{
    // указатели в начало и в конец массива
    int i=0;
    int j=size-1;
    //центральный элемент массива
    double mid=mas[size/2];
    // делим массив
    do
    {
        // пробегаем элементы, ищем те которые нужно перекинуть в другую часть
        // в левой части массива пропускаем (оставляем на месте) эоементы, которые меньше центрального
        while (mas[i]<mid)
        {
            i++;
        }
        // в правой части пропускаем элементы, которые больше центрального
        while (mas[j]>mid)
        {
            j--;
        }
        if(i<=j)
        {
            double tmp=mas[i];
            mas[i]=mas[j];
            mas[j]=tmp;
            i++;
            j--;
        }
    }
    while (i<=j);
    
    //рекурсивные вызовы, если осталось, что сортировать
    if(j>0)
    {
        //левый кусок
        QsortRecursive(mas, j+1);
    }
    if(i<size)
    {
        //правый кусок
        QsortRecursive(&mas[i], size-i);
    }
}


void MainWindow::on_pushButton_fast_clicked()//быстрая сортировка
{
    allowchanged=false;
    
    if(size>99999)
    {
        QMessageBox::warning(this,"Предупреждение","Возможно программа будет тормозить, потому что слишком много ячеек");
    }
    bool correct = isCorrectValues();//функция проверки
    if(!correct)
    {
        ui->label_min->clear();
        ui->label_max->clear();
        ui->label_avg->clear();
        ui->label_numberinclude->clear();
        ui->textEdit_nubmercell->clear();
        QMessageBox::information(this,"Ошибка","Некорректные данные");
        allowchanged=true;
        return;
    }
    readMassive();// получаем массив из таблицы
    //скопированный код сортировки
    
    QsortRecursive(mas, size);
    
    writeMassive();//выводим отсортированный массив
    allowchanged=true;
}

void MainWindow::on_pushButton_monkey_clicked()//обезьянья сортировка
{
    allowchanged=false;
    bool correct = isCorrectValues();//функция проверки
    if(!correct)
    {
        ui->label_min->clear();
        ui->label_max->clear();
        ui->label_avg->clear();
        ui->label_numberinclude->clear();
        ui->textEdit_nubmercell->clear();
        QMessageBox::information(this,"Ошибка","Некорректные данные");
        allowchanged=true;
        return;
    }
    readMassive();// получаем массив из таблицы
    
    if(size>5)
    {
        QMessageBox::information(this,"Ошибка","Обезьянья сортировка может быть использована для массива, состоящего не более, чем из 5 элементов!");
        return;
    }
    //скопированный код сортировки
    bogoSort();//сортировка
    bool masCorrect=isCorrect();// корректность массива
    if(!masCorrect)
    {
        QMessageBox::information(this,"Ошибка","Неудалось отсортировать");
        return;
    }
    else
    {
        writeMassive();//выводим отсортированный массив
    }
    allowchanged=true;
    
}

bool MainWindow::isCorrect()// функция для обезьяней сортировки
{
    for(int i=0; i<size-1; i++)
    {
        if(mas[i]>mas[i+1])//если текущий больше чем следующий
        {
            return false;
        }
    }
    return true;
}

void MainWindow::shuffle()// функция для обезьяней сортировки
{
    for (int i=0;i<size ;i++ )
    {
        std::swap(mas[i], mas[(rand()% size)]);//swap-меняет местами массив
    }
}

void MainWindow::bogoSort()//функция для обезьяней сортировки
{
    int count=0;
    while(!isCorrect())
    {
        if(count==1000)
        {
            break;
        }
        shuffle();
        count++;
    }
}


void MainWindow::on_pushButton_gnom_clicked()//гномья сортировка
{
    allowchanged=false;
    
    if(size>99999)
    {
        QMessageBox::warning(this,"Предупреждение","Возможно программа будет тормозить, потому что слишком много ячеек");
    }
    bool correct = isCorrectValues();//функция проверки
    if(!correct)
    {
        ui->label_min->clear();
        ui->label_max->clear();
        ui->label_avg->clear();
        ui->label_numberinclude->clear();
        ui->textEdit_nubmercell->clear();
        QMessageBox::information(this,"Ошибка","Некорректные данные");
        allowchanged=true;
        return;
    }
    readMassive();// получаем массив из таблицы
    //скопированный код сортировки
    // сортировка
    int i=1; //счетчик
    while (i<size)
    {
        if(i==0)
        {
            i=1;
        }
        if(mas[i-1]<mas[i]||(abs(mas[i-1]-mas[i])<pow(10,-5))) // реализация mas[i-1] <=mas[i] в типе double
        {
            ++i; //идем вперед
        }
        else
        {
            // меняем местами
            double tmp=mas[i];
            mas[i]=mas[i-1];
            mas[i-1]=tmp;
            
            // идем назад
            --i;
        }
    }
    writeMassive();
    allowchanged=true;
}

void MainWindow::on_pushButton_search_clicked()//поиск
{

    int size=ui->tableWidget->rowCount();
    bool flag = false;
    double desiredValue=ui->lineEdit_desiredvalue->text().toDouble(&flag);
    allowchanged = false;
    bool correct = isCorrectValues();//функция проверки на корректность веденных данных
    if(!correct)
    {

        ui->label_numberinclude->clear();
        ui->textEdit_nubmercell->clear();

        QMessageBox::information(this,"Ошибка","Некорректные данные");
        allowchanged=true;
        return;
    }

    if(isCorrectValues())
    {
        if(size==1)
        {
            if(!flag)
            {
                ui->label_numberinclude->setText("Некорректное значение");
                ui->textEdit_nubmercell->clear();
                return;
            }
            if(abs(desiredValue - ui->tableWidget->item(0,0)->text().toDouble())<pow(10,-15))
            {

                ui->textEdit_nubmercell->setText("1");
                ui->label_numberinclude->setText("1");
                ui->tableWidget->item(0,0)->setBackground(Qt::yellow);

            }
            else
            {
                ui->label_numberinclude->setText("0");
                ui->textEdit_nubmercell->setText("Не найдено!");
                ui->tableWidget->item(0,0)->setBackground(Qt::white);
            }
        }
        else
        {
            if(size>2000)
            {
                QMessageBox::warning(this,"Предупреждение","Возможно программа будет тормозить, потому что слишком много ячеек");
            }

//            bool correct = isCorrectValues();//функция проверки на корректность веденных данных
//            if(!correct)
//            {

//                ui->label_numberinclude->clear();
//                ui->textEdit_nubmercell->clear();

//                QMessageBox::information(this,"Ошибка","Некорректные данные");
//                return;
//            }
            readMassive();// считываем массив (создаем и кладем текущие значения)

            if(size==0)//если в массиве нет элементов
            {
                ui->label_numberinclude->setText("Заполните массив!");
                ui->textEdit_nubmercell->clear();
                return;
            }

            for(int i=0; i<size; i++)
            {
                ui->tableWidget->item(i,0)->setBackground(Qt::white);// закрашиваем все ячейки изначальнов белый цвет
            }

//            allowchanged = false;
            // ui->label_->clear();


            if(!flag)
            {
                ui->label_numberinclude->setText("Некорректное значение");
                ui->textEdit_nubmercell->clear();
                return;
            }
            else {

                bool massSorted = isCorrect();//проверяем отсортирован ли массив
                int searchCount = 0;
                QString searchItemsNumbers = ""; // переменная которая будет хранить в себе номера строк для вывода

                if(!massSorted) //если массив не отсортирован
                {//линейный поиск
                    for(int i =0;i<size;i++)
                    {
                        if(abs(mas[i]-desiredValue)<pow(10,-15))
                        {
                            searchCount++;
                            ui->tableWidget->item(i,0)->setBackground(Qt::yellow);

                            if(searchItemsNumbers !="") // если в строке уже есть зн-я
                            {
                                searchItemsNumbers.append(", ");
                            }
                            //добавляем число
                            searchItemsNumbers.append(QString::number(i+1));//добавляем номера строка в которых найдено совпдаение
                        }
                    }
                }
                else//массив отсортирован
                {//бинарный поиск
                    int mid = size /2;//поиск номера среднего элемента
                    int left = 0;
                    int right = size -1;

                    int lastLeft = -1;
                    int lastRight = -1;
                    while(abs(mas[mid]-desiredValue)>pow(10,-15) && abs(mas[mid+1]-desiredValue)>pow(10,-15))
                    {
                        if((left == lastLeft) && (right == lastRight))//граница не изменена
                        {
                            break;//выход из цикла так как не найдено значение
                        }
                        lastLeft = left;
                        lastRight = right;
                        if(desiredValue<mas[mid])//числло которое ищем меньше центрального элемента
                        {
                            right = mid;//устанавливаем правую границу
                        }
                        else//число которое ищем больше центрального эл-та
                        {
                            left = mid;//устанавливаем левую границу
                        }
                        mid = (left+right)/2;//ищем номер нового центрального эл-та
                    }


                    if(abs(mas[mid]-desiredValue)<pow(10,-15))
                    {
                        //если совпадает центр число то ничего не меняем
                    }

                    else if(abs(mas[mid+1]-desiredValue)<pow(10,-15))//если искомое число справа от центра
                    {
                        mid ++;//сдвигаем границу вправо
                    }
                    else
                    {
                        mid = -1 ;//сдвигаем границу влево
                    }

                    if(mid != -1)//если значение было найдено
                    {
                        if(mid>0)//если не в самом левом углу
                        {
                            int index = mid -1;
                            while(abs(mas[index] - desiredValue) <pow(10,-15))//пока число из массива с номером индекса равно искомому
                            {
                                if (index == 0)//дошли до левой границы
                                {
                                    index--;
                                    break;//выходим из цикла
                                }
                                index -- ;//идем влево
                            }
                            index++;//сдвигаемся вправо так как жостигли невозможного элемента

                            for(int i =index; i<mid; i++)//идем по всем индексам
                            {
                                searchCount++;//ув-ем кол-во найденных элементов на 1
                                ui->tableWidget->item(i,0)->setBackground(Qt::yellow);//красим элемент в синий

                                if(searchItemsNumbers != "")
                                {
                                    searchItemsNumbers.append(", ");
                                }
                                searchItemsNumbers.append(QString::number(i+1));//добавляем номер столбца
                            }
                        }
                        searchCount++;
                        ui->tableWidget->item(mid,0)->setBackground(Qt::yellow);
                        if(searchItemsNumbers != "")
                        {
                            searchItemsNumbers.append(", ");
                        }
                        searchItemsNumbers.append(QString::number(mid+1));
                        if(mid<size-1)//если мы не в самом правом углу
                        {
                            int index = mid+1;//начинаем с эл-та который стоит слева
                            while(abs(mas[index]-desiredValue)<pow(10,-15))//пока число из массива с номером индекса равно искомому
                            {
                                if(index == size -1)//если дошли до правой границы
                                {
                                    index ++;//ув-ем индекс
                                    break;//выходим из цикла
                                }
                                index++;//сдвигаем индекс влево
                            }
                            index--;//сдвигаем индекс вправо т к дошли до невозможного эл-та
                            for(int i = mid+1; i<=index;i++)
                            {
                                searchCount++;
                                ui->tableWidget->item(i,0)->setBackground(Qt::yellow);

                                if(searchItemsNumbers != "")
                                {
                                    searchItemsNumbers.append(", ");
                                }
                                searchItemsNumbers.append(QString::number(i+1));
                            }
                        }
                    }
                    else//нет искомых чисел в таблице
                    {
                        searchItemsNumbers = "Не найдено!";
                    }
                }
                ui->label_numberinclude->setNum(searchCount); //вводим кол-во найденных элементов
                ui->textEdit_nubmercell->setText(searchItemsNumbers);//выводим номера строк
            }
        }

    }
    else
    {
        QMessageBox::information(this,"Ошибка","Не введено значение");
        allowchanged=true;
        return;

    }
//    writeMassive();
    allowchanged = true;
}

void MainWindow::on_pushButton_deldublicate_clicked()//удаление дубликатов
{
    ui->label_rand->clear();
    ui->label_numberinclude->clear();
    ui->textEdit_nubmercell->clear();
    
    bool correct = isCorrectValues();//функция проверки на корректность веденных данных
    if(size>29999)
    {
        QMessageBox::warning(this,"Предупреждение","Возможно программа будет тормозить, потому что слишком много ячеек");
    }
    if(!correct)
    {
        ui->label_min->clear();
        ui->label_max->clear();
        ui->label_avg->clear();
        ui->label_numberinclude->clear();
        ui->textEdit_nubmercell->clear();
        
        QMessageBox::information(this,"Ошибка","Некорректные данные");
        return;
    }
    readMassive();// считываем массив из таблицы
    if(size<=0)
    {
        QMessageBox::information(this,"Ошибка","В таблице нет элементов");
    }
    double *temp_mas= new double[size]; // создаем временный массив для хранения без повтора
    int noPovtorCount=0;// кол-во элементов в массиве без повтора
    bool sorted=isCorrect();
    if(sorted)
    {
        //заносим самое первое значение
        temp_mas[0]=mas[0];
        noPovtorCount++;
        
        //ищем повторы
        for (int i=1 ;i<size ;i++ )
        {
            if(abs(mas[i-1]-mas[i])>pow(10,-5))
            {
                temp_mas[noPovtorCount]=mas[i];
                noPovtorCount++;
            }
        }
        
    }
    else
    {
        QMessageBox::warning(this,"Ошибка","Массив не отсортирован");
        //удаляем память чтобы избежать утечки
        delete [] temp_mas;
        temp_mas=nullptr;
        return;
    }
    
    // удаляем старый массив
    delete [] mas;
    mas=nullptr;
    
    //Создаем новый но уже без повторов
    mas =new double [noPovtorCount];
    size=noPovtorCount;
    for (int i=0;i<noPovtorCount ;i++ )
    {
        mas[i]=temp_mas[i];//заносим новые данные в массив
    }
    
    //удаляем память, чтобы избежать утечки
    delete [] temp_mas;
    temp_mas=nullptr;
    
    ui->spinBox->setValue(noPovtorCount);// устанавливаем новое кол-во строк
    writeMassive();
}
