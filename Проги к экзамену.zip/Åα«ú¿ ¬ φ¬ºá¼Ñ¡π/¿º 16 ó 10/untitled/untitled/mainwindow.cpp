#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMessageBox"
#include "QValidator"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->lineEdit->setValidator(new QRegularExpressionValidator(QRegularExpression("[A-F a-f 0-9 -]*")));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{

    bool flag;
    QString str=ui->lineEdit->text();
    long long value=str.toLongLong(&flag,16);
    QString nextValue;
    nextValue.setNum(value,10);
    double isvalue=value;
    if(qIsInf(isvalue))
    {
      QMessageBox::information(nullptr,"Ошибка","Число слишком большое");
      ui->label->clear();
      return;
    }

    if(value>0 )
    {
     ui->label->setText(nextValue);
    }
    else if(value<0)
    {
        value=-value;
      ui->label->setText(nextValue);
    }

}
