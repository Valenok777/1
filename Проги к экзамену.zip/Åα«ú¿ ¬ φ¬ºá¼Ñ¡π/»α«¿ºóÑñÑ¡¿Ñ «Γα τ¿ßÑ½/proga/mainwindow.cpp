#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMessageBox"
#include "QDebug"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tableWidget->setColumnCount(1);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_spinBox_valueChanged(int arg1)
{
    ui->tableWidget->setRowCount(arg1);

    for (int i=0;i<arg1;i++)
    {
        QTableWidgetItem *item=ui->tableWidget->item(i,0);
        if(item==nullptr)
        {
            item=new QTableWidgetItem;
                        item->setText("-1");
            ui->tableWidget->setItem(i,0,item);
        }
    }
}

void MainWindow::on_pushButton_1_clicked()
{
    double rows=ui->tableWidget->rowCount();
    double count = 0;
    double pro = 1;
    for (int i=0;i<rows;i++)
    {
      double val=ui->tableWidget->item(i,0)->text().toDouble();

      if(val<0 )
      {
          count++;
          pro *=val;
      }
    }
    if (count<=1)
    {
    QMessageBox::information(this,"Ошибка","Произведение нельзя высчитать ");
    }
    else
    QMessageBox::information(this,"Ошибка","Произведение отрицательных чисел : " + QString::number(pro));
}
