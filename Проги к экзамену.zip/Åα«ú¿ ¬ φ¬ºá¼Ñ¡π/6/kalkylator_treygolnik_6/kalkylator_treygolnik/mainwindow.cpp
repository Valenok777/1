#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui -> lineEdit_ygol_A -> setMaxLength(9);  // макс длина вводимого текста в "Угол А"
    ui -> lineEdit_ygol_B -> setMaxLength(9);  // макс длина вводимого текста в "Угол В"
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_res_clicked()//характеристики, проверка введенных данных
{
    double x1, x2, y1, y2, ygol_A, ygol_B;
    bool fl;//флаг успешности преобразования

    ygol_A=ui -> lineEdit_ygol_A -> text().toDouble(&fl);
    ygol_B=ui -> lineEdit_ygol_B -> text().toDouble(&fl);

    x1=0;
    x2=0;
    y1=0;
    y2=0;

    if(fl)
    {
        // проверка параметра угла A
        ygol_A = ui -> lineEdit_ygol_A -> text().toDouble(&fl);
        if(fl)//вместо вложенных if
        {
            if(ygol_A < 0)//проверка
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Параметр \"Угол А\" должен быть не меньше 0 ", QMessageBox::Ok);//вывод ошибки
                ui->label_per->clear();//Очистка периметра
                ui->label_plo->clear();//Очистка площади
            }
            else if ((fabs(isinf(ygol_A)-0) > 1e-10)||(fabs(isnan(ygol_A)-0) > 1e-10))//в ячейке находится inf или nan
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Угол А\"",QMessageBox::Ok);//вывод ошибки
                ui->label_per->clear();//Очистка периметра
                ui->label_plo->clear();//Очистка площади
            }
        }
        else
        {
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Угол A\"",QMessageBox::Ok);//вывод ошибки
            ui->label_per->clear();//Очистка периметра
            ui->label_plo->clear();//Очистка площади
        }
    }

    if(fl)
    {
        // проверка параметра угла B
        ygol_B = ui -> lineEdit_ygol_B -> text().toDouble(&fl);
        if(fl)//вместо вложенных if
        {
            if(ygol_B < 0)//проверка
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Параметр \"Угла B\" должен быть не меньше 0 ", QMessageBox::Ok);//вывод ошибки
                ui->label_per->clear();//Очистка периметра
                ui->label_plo->clear();//Очистка площади
            }
            else if ((fabs(isinf(ygol_B)-0) > 1e-10)||(fabs(isnan(ygol_B)-0) > 1e-10))//в ячейке находится inf или nan
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Угла B\"",QMessageBox::Ok);//вывод ошибки
                ui->label_per->clear();//Очистка периметра
                ui->label_plo->clear();//Очистка площади
            }
        }
        else
        {
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"Угол B\"",QMessageBox::Ok);//вывод ошибки
            ui->label_per->clear();//Очистка периметра
            ui->label_plo->clear();//Очистка площади
        }
    }

    if(fl)
    {
        // проверка параметра "x1"
        x1 = ui -> lineEdit_x1 -> text().toDouble(&fl);
        if(fl)//вместо вложенных if
        {
            if((fabs(isinf(x1)-0) > 1e-10)||(fabs(isnan(x1)-0) > 1e-10))//в ячейке находится inf или nan
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Неверное значение параметра \"координаты x1\"",QMessageBox::Ok);//вывод ошибки
                ui->label_per->clear();//Очистка периметра
                ui->label_plo->clear();//Очистка площади
            }
        }
        else
        {
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"координаты x1\"",QMessageBox::Ok);//вывод ошибки
            ui->label_per->clear();//Очистка периметра
            ui->label_plo->clear();//Очистка площади
        }
    }

    if(fl)
    {
        // проверка параметра "y1"
        y1 = ui -> lineEdit_y1 -> text().toDouble(&fl);
        if(fl)//вместо вложенных if
        {
            if((fabs(isinf(y1)-0) > 1e-10)||(fabs(isnan(y1)-0) > 1e-10))//в ячейке находится inf или nan
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Неверное значение параметра \"координаты y1\"",QMessageBox::Ok);//вывод ошибки
                ui->label_per->clear();//Очистка периметра
                ui->label_plo->clear();//Очистка площади
            }
        }
        else
        {
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"координаты y1\"",QMessageBox::Ok);//вывод ошибки
            ui->label_per->clear();//Очистка периметра
            ui->label_plo->clear();//Очистка площади
        }
    }

    if(fl)
    {
        // проверка параметра "x2"
        x2 = ui -> lineEdit_x2 -> text().toDouble(&fl);
        if(fl)//вместо вложенных if
        {
            if((fabs(isinf(x2)-0) > 1e-10)||(fabs(isnan(x2)-0) > 1e-10))//в ячейке находится inf или nan
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Неверное значение параметра \"координаты x2\"",QMessageBox::Ok);//вывод ошибки
                ui->label_per->clear();//Очистка периметра
                ui->label_plo->clear();//Очистка площади
            }
        }
        else
        {
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"координаты x2\"",QMessageBox::Ok);//вывод ошибки
            ui->label_per->clear();//Очистка периметра
            ui->label_plo->clear();//Очистка площади
        }
    }

    if(fl)
    {
        // проверка параметра "y2"
        y2 = ui -> lineEdit_y2 -> text().toDouble(&fl);
        if(fl)//вместо вложенных if
        {
            if((fabs(isinf(y2)-0) > 1e-10)||(fabs(isnan(y2)-0) > 1e-10))//в ячейке находится inf или nan
            {
                fl = false;
                QMessageBox::information(this,"Ошибка","Неверное значение параметра \"координаты y2\"",QMessageBox::Ok);//вывод ошибки
                ui->label_per->clear();//Очистка периметра
                ui->label_plo->clear();//Очистка площади
            }
        }
        else
        {
            QMessageBox::information(this,"Ошибка","Неверное значение параметра \"координаты y2\"",QMessageBox::Ok);//вывод ошибки
            ui->label_per->clear();//Очистка периметра
            ui->label_plo->clear();//Очистка площади
        }
    }

    if(((ygol_A+ygol_B)>179.9999999999)||((ygol_A+ygol_B)<0.0000001))//проверка суммы углов
    {
        fl = false;
        double ctorona_c, Plo, ctorona;
        Plo=0;
        ctorona_c=sqrt(pow((x2-x1),2)+pow((y2-y1),2));//находим одну сторону
        ctorona=ctorona_c*2;
        ui->label_per->setNum(ctorona);//Очистка периметра
        ui->label_plo->setNum(Plo);//Очистка площади
    }

    if(fl) // вычисления и вывод результата
    {
        double ctorona_c, ctorona_b, ctorona_a, plo, ygol_C, pi, per;
        ctorona_c=sqrt(pow(x2-x1,2)+pow(y2-y1,2));//находим одну сторону
        pi = acos(-1);//число пи
        ygol_C=180-(ygol_A+ygol_B);//находим третий угол
        plo=(ctorona_c*ctorona_c*sin(ygol_A*pi/ 180)*sin(ygol_B*pi/ 180))/(2*sin(ygol_C*pi/ 180));//считаем  площадь
        ctorona_b=(ctorona_c*sin(ygol_B*pi/ 180))/sin(ygol_C*pi/ 180);//находим третий сторону b
        ctorona_a=(ctorona_c*sin(ygol_A*pi/ 180))/sin(ygol_C*pi/ 180);//находим третий сторону a
        per=ctorona_a+ctorona_b+ctorona_c;

        ui -> label_plo -> setNum(plo);//выводим площадь
        ui -> label_per -> setNum(per);//выводим периметр
    }
}

void MainWindow::on_pushButton_clicked()//очистка введенных данных и полученного результата
{
    ui->lineEdit_ygol_A->clear();//Очистка угла А
    ui->lineEdit_ygol_B->clear();//Очистка угла В
    ui->lineEdit_x1->clear();//Очистка х1
    ui->lineEdit_x2->clear();//Очистка х2
    ui->lineEdit_y2->clear();//Очистка у2
    ui->lineEdit_y1->clear();//Очистка у1
    ui->label_per->clear();//Очистка периметра
    ui->label_plo->clear();//Очистка площади
}

