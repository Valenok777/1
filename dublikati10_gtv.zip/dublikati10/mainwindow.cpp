#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->spinBox_row->setMaximum(MAX_MAS_SIZE);
    ui->spinBox_row->setMinimum(MIN_MAS_SIZE);
    ui->label_max->setVisible(false);
    ui->label_min->setVisible(false);
    ui->label_srednee->setVisible(false);
    ui->label_kolvo_ans->setVisible(false);
    ui->label_kolvo->setVisible(true);
    ui->tableWidget_2->setEditTriggers(QTableWidget::NoEditTriggers);//запрещаем писать
    mas_table1=nullptr;
    
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_tableWidget_cellChanged(int row, int column)//проверка вводимых в таблицу значений
{
    bool fl;
    ui->tableWidget->item(row,column)->text().toDouble(&fl);
    if(fl&&!((qIsNaN(ui->tableWidget->item(row,column)->text().toDouble(&fl)))||(qIsInf(ui->tableWidget->item(row,column)->text().toDouble(&fl)))))//проверка на число и NAN/INF
        ui->tableWidget->item(row,column)->setBackground(Qt::white); // setBackground
    else
        ui->tableWidget->item(row,column)->setBackground(Qt::red); // setBackground
    ui->label_max->clear();//очистка мин
    ui->label_min->clear();
    ui->label_srednee->clear();
    ui->label_kolvo_ans->clear();
    ui->tableWidget_2->clearContents();
    ui->tableWidget_2->setRowCount(0);
    
}

void MainWindow::on_spinBox_row_valueChanged(int row)//изменение колва рядов в спинбоксе
{
    ui->tableWidget->setRowCount(row);
    ui->tableWidget_2->clearContents();
    ui->tableWidget_2->setRowCount(0);
    ui->label_kolvo_ans->clear();
}


void MainWindow::on_pushButton_clear_clicked()//очистка
{
    ui->tableWidget->clearContents();//очистка таблицы
    ui->label_max->clear();//очистка мин
    ui->label_min->clear();
    ui->label_srednee->clear();
    ui->tableWidget_2->clearContents();
    ui->lineEdit_poisk->clear();
    ui->label_kolvo_ans->clear();
    ui->tableWidget_2->setRowCount(0);
    ui->lineEdit_fill->clear();
    ui->tableWidget->setRowCount(1);
    ui->spinBox_row->setValue(1);

}


void MainWindow::on_pushButton_rand_clicked()//рандомное заполенение
{
    mnogo();
    int row=ui->tableWidget->rowCount();
    ui->label_max->clear();//очистка мин
    ui->label_min->clear();
    ui->label_srednee->clear();
    ui->label_kolvo_ans->clear();
    ui->tableWidget_2->clearContents();
    
    double val;
    for (int i=0;i<row;i++)//идем по таблице
    {
        if (ui->tableWidget->item(i,0)==nullptr)//ячейка пустая
        {
            QTableWidgetItem * ti; //создали указатель
            ti =  new QTableWidgetItem(); //выделяем память
            ui->tableWidget->setItem(i,0,ti); //помещаем ячейку в таблицу
        }
        ui->tableWidget->item(i,0)->setBackground(Qt::white);
        val=0.1*(rand()%2001-1000); // от -100 до 100
        //mas_table1[i]=val;//присваиваем элементу рандомное значение
        ui->tableWidget->item(i,0)->setText(QString::number(val));//выводим рандомное значение
    }
    delete[] mas_table1;
    mas_table1 = nullptr;
}


void MainWindow::quick_sort(double *mas_table1,int row)//быстрая сортировка
{
    double razdel = mas_table1[row/2];//центральное значение
    int up=0;//начало
    int down=row-1;//конец
    do{
        while(mas_table1[up]<razdel)//пропускаем значения, если они в нужной половине
        {
            up++;
        }
        while(mas_table1[down]>razdel)//пропускаем значения, если они в нужной половине
        {
            down--;
        }
        if(up<=down)//если границы не совместились
        {
            double b = mas_table1[up]; // создали дополнительную переменную
            mas_table1[up] = mas_table1[down]; // меняем местами
            mas_table1[down] = b;
            up++;
            down--;
        }
    }
    while(up<=down);//пока границы не совместились
    
    if(down>0)//нижняя границыа больше нуля
        quick_sort(mas_table1, down+1);//рекурсия в верней половине
    if(up<row)//верхняя границыа меньше размера
        quick_sort(&mas_table1[up], row-up);//рекурсия в нижней половине
}

void MainWindow::rascheska(int row)//расческа сортировка
{

    if(sorted(mas_table1,row))
        QMessageBox::information(this,"Зачем?","Массив уже отсортирован");
    else{
        int step=row;//задаем шаг
        int i;
        bool priznak_perest=true;//флаг перестановки
        while(step>1||priznak_perest)
        {
            if(step>1)
            {
                step= static_cast<int>(step/1.247);//
            }
            priznak_perest=false;
            i=0;
            while(i+step<row)
            {
                if(mas_table1[i]>mas_table1[i+step])//сравниваем  значения
                {
                    double b = mas_table1[i]; // создали дополнительную переменную
                    mas_table1[i] = mas_table1[i+step]; // меняем местами
                    mas_table1[i+step] = b;
                    priznak_perest=true;
                }
                i+=1;
            }
        }
    }
    delete[] mas_table1;
    mas_table1 = nullptr;
}

void MainWindow::buble(int row)//пузырьковая сортировка
{

    if(sorted(mas_table1,row))
        QMessageBox::information(this,"Зачем?","Массив уже отсортирован");
    else{
        int i=0;//первый элемент
        while (i<row-1) //пока первое число меньше размера
        {
            int j=i+1;
            while(j<row)//пока второе число меньше размера и не совместились в конце
            {
                if (mas_table1[i] > mas_table1[j])//сравниваем соседние значения
                {
                    double b = mas_table1[i]; // создали дополнительную переменную
                    mas_table1[i] = mas_table1[j]; // меняем местами
                    mas_table1[j] = b;
                }
                j=j+1;
            }
            i=i+1;
        }
    }

}

void MainWindow::gnom(int row)//гномья сортировка
{

    if(sorted(mas_table1,row))
        QMessageBox::information(this,"Зачем?","Массив уже отсортирован");
    else{
        int i=0;//первый элемент
        while(i<row)
        {
            if(i==0||mas_table1[i-1]<=mas_table1[i])//сравниваем соседние значения
                i+=1;
            else//если сверху больше чем снизу
            {
                int j=i-1;
                double b = mas_table1[i]; // создали дополнительную переменную
                mas_table1[i] = mas_table1[j]; // меняем местами
                mas_table1[j] = b;
                i=j;
            }
        }
    }
    
}

void MainWindow::monkey(int row)//обезьянья сортировка
{
    if(row<11&&!sorted(mas_table1,row))
    {
        int limit = 1000000;
        for(int i=1;i<limit;i++)//попытка отсортировать за limit раз
        {
            for(int j=0;j<row-1;j++)//проходим по таблице
            {
                int r=rand()%row;
                double b = mas_table1[j]; // создали дополнительную переменную
                mas_table1[j] = mas_table1[r]; // меняем местами
                mas_table1[r] = b;
            }
            if(sorted(mas_table1,row))
                break;
            else if (limit-1==i&&!sorted(mas_table1,row)) {
                QMessageBox::information(this,"Ошибка","Не получилось отсортивать массив за 100000 попыток");
            }
        }
    }
    
    else if (sorted(mas_table1,row))
    {
        QMessageBox::information(this,"Зачем?","Массив уже отсортирован");
        
    }
    else if (row>10)
    {
        QMessageBox::information(this,"Ошибка","Сортировка будет выполняться очень долго. Выберите другой метод или уменьшите количество рядов до 10.");
    }
    delete[] mas_table1;
    mas_table1 = nullptr;
}



void MainWindow::on_pushButton_min_clicked()//поиск минимального
{
    //mnogo();
    int row=ui->tableWidget->rowCount();
    bool fl;//флаг успешной конвертации ячейки
    bool gl_fl=true;//фалг успешного создания массива
    for (int i=0;i<row;i++)//формирование массива
    {
        if (ui->tableWidget->item(i,0)==nullptr)//пустая ячейка
        {
            gl_fl=false;
            QTableWidgetItem * ti; //создали указатель
            ti =  new QTableWidgetItem(); //выделяем память
            ui->tableWidget->setItem(i,0,ti); //помещаем ячейку в таблицу;
        }
        else
        {
            double v=ui->tableWidget->item(i,0)->text().toDouble(&fl);//конвертируем
            if(fl&&!(qIsInf(v)||qIsNaN(v)))//если сконвертировано
            {
                ui->tableWidget->item(i,0)->setBackground(Qt::white);//красим ячейку в белый
            }
            
            else {
                ui->tableWidget->item(i,0)->setBackgroundColor(Qt::red);//красим ячейку в красный
                gl_fl=false;
            }
            
        }
    }
    if(gl_fl)//cформировали правильно
    {
        double min=ui->tableWidget->item(0,0)->text().toDouble();//делаем первое число минимумом
        int i=1;
        while (i<row)
        {
            double val = ui->tableWidget->item(i,0)->text().toDouble();
            if(min>val)
                min=val;//изменяем минимум, если он бошльше числа
            i++;
        }
        ui->label_min->setNum(min);
        ui->label_min->setVisible(true);
    }
    else {
        QMessageBox::information(this,"Ошибка","В таблице содержатся некорректные значения или значения, которые невозможно посчитать");
        err_str();
        ui->label_max->clear();//очистка мин
        ui->label_min->clear();
        ui->label_srednee->clear();
    }
    delete[] mas_table1;
    mas_table1 = nullptr;
}

void MainWindow::on_pushButton_srednee_clicked()//поиск среднего
{
    //mnogo();
    int row=ui->tableWidget->rowCount();
    bool fl;//флаг успешной конвертации ячейки
    bool gl_fl=true;//фалг успешного создания массива
    for (int i=0;i<row;i++)//формирование массива
    {
        if (ui->tableWidget->item(i,0)==nullptr)//пустая ячейка
        {
            gl_fl=false;
            QTableWidgetItem * ti; //создали указатель
            ti =  new QTableWidgetItem(); //выделяем память
            ui->tableWidget->setItem(i,0,ti); //помещаем ячейку в таблицу;
        }
        else
        {
            double val=ui->tableWidget->item(i,0)->text().toDouble(&fl);//конвертируем
            if(fl&&!((qIsNaN(val))||(qIsInf(val))))//если сконвертировано
            {
                ui->tableWidget->item(i,0)->setBackground(Qt::white);//красим ячейку в белый
            }
            
            else {
                ui->tableWidget->item(i,0)->setBackgroundColor(Qt::red);//красим ячейку в красный
                gl_fl=false;
                
            }
            
        }
    }
    if(gl_fl)
    {
        double srednee=0;
        double sr;
        for (int i=0;i<row;i++)
        {
            double val=ui->tableWidget->item(i,0)->text().toDouble();
            srednee+=val;//считаем сумму всего массива
        }
        sr=srednee/row;//среднее арифметическое
        
        ui->label_srednee->setNum(sr);
        ui->label_srednee->setVisible(true);
    }
    else
    {
        QMessageBox::information(this,"Ошибка","В таблице содержатся некорректные значения или значения, которые невозможно посчитать");
        err_str();
        ui->label_max->clear();//очистка мин
        ui->label_min->clear();
        ui->label_srednee->clear();
    }
}

void MainWindow::on_pushButton_max_clicked()//определение максимума и его вывод
{
    //mnogo();
    int row=ui->tableWidget->rowCount();
    bool fl;//флаг успешной конвертации ячейки
    bool gl_fl=true;//фалг успешного создания массива
    for (int i=0;i<row;i++)//формирование массива
    {
        if (ui->tableWidget->item(i,0)==nullptr)//пустая ячейка
        {
            gl_fl=false;
            QTableWidgetItem * ti; //создали указатель
            ti =  new QTableWidgetItem(); //выделяем память
            ui->tableWidget->setItem(i,0,ti); //помещаем ячейку в таблицу;
        }
        else
        {
            double v=ui->tableWidget->item(i,0)->text().toDouble(&fl);//конвертируем
            if(fl&&!((qIsNaN(v))||(qIsInf(v))))//если сконвертировано
            {
                ui->tableWidget->item(i,0)->setBackground(Qt::white);//красим ячейку в белый
            }
            
            else
            {
                ui->tableWidget->item(i,0)->setBackgroundColor(Qt::red);//красим ячейку в красный
                gl_fl=false;
            }
        }
    }
    if(gl_fl)
    {
        double max=ui->tableWidget->item(0,0)->text().toDouble();//делаем первое число максимумом
        int i=1;
        while (i<row)
        {
            double val=ui->tableWidget->item(i,0)->text().toDouble();
            if(max<val)
                max=val;//изменяем максимум, если он меньше числа
            i+=1;
        }
        ui->label_max->setNum(max);
        ui->label_max->setVisible(true);
    }
    else {
        QMessageBox::information(this,"Ошибка","В таблице содержатся некорректные значения или значения, которые невозможно посчитать");
        err_str();
        ui->label_max->clear();//очистка мин
        ui->label_min->clear();
        ui->label_srednee->clear();
    }
}

void MainWindow::err_str()//подсветка строки с ошибкой
{
    int row=ui->tableWidget->rowCount();
    int err=row;
    bool fl=true;
    
    for (int i=row-1;i>-1;i--)//идем по таблице
    {
        if (ui->tableWidget->item(i,0)==nullptr)//пустая ячейка
            err=i;
        else {
            double val=ui->tableWidget->item(i,0)->text().toDouble(&fl);//преобразовали в число
            if(fl&&!((qIsNaN(val))||(qIsInf(val))))//если преобразовалось и не нан
            {
                err=row;//все хорошо
            }
            
            else {
                err=i;//записываем номер строки
                fl=false;
            }
            
            
        }
        if(err<row)//если были ошибочные строки
            ui->tableWidget->setCurrentCell(err,0);//подсветили строку с ошибкой
    }
}


bool MainWindow::sorted(double *mas_table1,int row)//флаг отсортированности массива
{
    for (int i=0;i<row-1;i++)
    {
        if(mas_table1[i]>mas_table1[i+1])//проверяем порядок элементов
        {
            return false;
            //monkey(row);//перестановка
        }
    }
    return true;
}
void MainWindow::on_pushButton_sort_clicked()//выполнение сортировки
{
    mnogo();
    int row=ui->tableWidget->rowCount();
    bool fl;//флаг успешной конвертации ячейки
    bool gl_fl=true;//фалг успешного создания массива

    mas_table1 = new double[row];

    for (int i=0;i<row;i++)//формирование массива
    {
        if (ui->tableWidget->item(i,0)==nullptr)//пустая ячейка
        {
            gl_fl=false;
            QTableWidgetItem * ti; //создали указатель
            ti =  new QTableWidgetItem(); //выделяем память
            ui->tableWidget->setItem(i,0,ti); //помещаем ячейку в таблицу;
        }
        else
        {
            mas_table1[i] = ui->tableWidget->item(i, 0)->text().toDouble(&fl);
            if(fl&&!((qIsNaN(mas_table1[i]))||(qIsInf(mas_table1[i]))))//если сконвертировано
            {
                ui->tableWidget->item(i,0)->setBackground(Qt::white);//красим ячейку в белый
            }
            
            else {
                ui->tableWidget->item(i,0)->setBackgroundColor(Qt::red);//красим ячейку в красный
                gl_fl=false;
            }
            
        }
    }
    if(gl_fl&&row!=1)//if массив сформирован правильно
    {

        int sposob=ui->comboBox_sort->currentIndex();
        switch (sposob)
        {
        case 0:
        {
            quick_sort(mas_table1,row);//быстрая сортировка
            break;
        }
        case 1:
        {
            rascheska(row);//расческа
            break;
        }
        case 2:
        {
            buble(row);//пузырек
            break;
        }
        case 3:
        {
            gnom(row);//гномья
            break;
        }
        case 4:
        {
            monkey(row);//обезьянья
            break;
        }
        default:
        {
            quick_sort(mas_table1,row);
            break;
        }
        }

        for (int i=0;i<row;i++)//заполнение таблицы без проверки т.к. глфл=тру
            ui->tableWidget->item(i,0)->setText(QString::number(mas_table1[i]));
        delete[] mas_table1;
        mas_table1 = nullptr;
        gl_fl=true;
        on_pushButton_max_clicked();
        on_pushButton_min_clicked();
        on_pushButton_srednee_clicked();
    }
    else if (gl_fl&&row==1)
    {
        QMessageBox::information(this,"Зачем?","Зачем сортировать одно число?!?!?");
        
    }
    else {
        QMessageBox::information(this,"Ошибка","В таблице содержатся некорректные значения или значения, которые невозможно посчитать");
        err_str();
        ui->label_max->clear();//очистка мин
        ui->label_min->clear();
        ui->label_srednee->clear();
    }
    delete[] mas_table1;
    mas_table1 = nullptr;

}


void MainWindow::on_pushButton_poisk_clicked()//нажатие кнопки поиск и выполнение поиска
{
    int row=ui->tableWidget->rowCount();
    mnogo();
    ui->tableWidget_2->clearContents();
    bool fl;//флаг успешной конвертации ячейки
    bool gl_fl=true;//фалг успешного создания массива
    mas_table1 = new double[row];
    for (int i=0;i<row;i++)//формирование массива
    {
        if (ui->tableWidget->item(i,0)==nullptr)//пустая ячейка
        {
            gl_fl=false;
            QTableWidgetItem * ti; //создали указатель
            ti =  new QTableWidgetItem(); //выделяем память
            ui->tableWidget->setItem(i,0,ti); //помещаем ячейку в таблицу;
        }
        else
        {
            mas_table1[i]=ui->tableWidget->item(i,0)->text().toDouble(&fl);//конвертируем
            if(fl&&!((qIsNaN(mas_table1[i]))||(qIsInf(mas_table1[i]))))//если сконвертировано
            {
                ui->tableWidget->item(i,0)->setBackground(Qt::white);//красим ячейку в белый
            }

            else {
                ui->tableWidget->item(i,0)->setBackgroundColor(Qt::red);//красим ячейку в красный
                gl_fl=false;
            }

        }
    }
    if(gl_fl)
    {
        bool flp;
        int n=0;
        double num=ui->lineEdit_poisk->text().toDouble(&flp);//считали и преобразовываем искомое число
        if(flp&&!((qIsNaN(num))||(qIsInf(num))))//если вещественное число
        {
            if(sorted(mas_table1,row))//если массив отсортирован
            {
                for (int i=0; i<row;i++)
                {
                    if(abs(mas_table1[i]-num)<1e-10)
                    {
                        ui->tableWidget_2->setRowCount(n+1);
                        QTableWidgetItem * ti; //создали указатель
                        ti =  new QTableWidgetItem(); //выделяем память
                        ui->tableWidget_2->setItem(n,0,ti); //помещаем ячейку в таблицу;
                        ui->tableWidget_2->item(n,0)->setText(QString::number(i+1));
                        n=n+1;
                    }
                    else if (num<mas_table1[i])
                        break;
                }
            }
            else//если неотсортирован
            {
                for (int i=0; i<row;i++)
                {
                    if(abs(mas_table1[i]-num)<1e-10)
                    {
                        ui->tableWidget_2->setRowCount(n+1);
                        QTableWidgetItem * ti; //создали указатель
                        ti =  new QTableWidgetItem(); //выделяем память
                        ui->tableWidget_2->setItem(n,0,ti); //помещаем ячейку в таблицу;
                        ui->tableWidget_2->item(n,0)->setText(QString::number(i+1));
                        n=n+1;
                    }
                }
            }
            ui->label_kolvo_ans->setNum(n);
            ui->label_kolvo_ans->setVisible(true);
            if(n==0)
            {
                QMessageBox::information(this,"Ошибка","В массиве нет такого числа:(",QMessageBox::Ok);
                ui->tableWidget_2->clearContents();
                ui->tableWidget_2->setRowCount(0);
            }
            on_lineEdit_poisk_textChanged();//окрашивание искомого
        }
        else
        {
            QMessageBox::information(this,"Ошибка","Неверное значение искомого числа",QMessageBox::Ok);
            on_lineEdit_poisk_textChanged();//окрашивание искомого

        }
        delete [] mas_table1;
        mas_table1 = nullptr;
    }
    else {
        QMessageBox::information(this,"Ошибка","В таблице содержатся некорректные значения или значения, которые невозможно посчитать");
        err_str();//позиционирование на ошибке
        ui->label_max->clear();//очистка
        ui->label_min->clear();
        ui->label_srednee->clear();
        ui->label_kolvo_ans->clear();

    }
    delete[] mas_table1;
    mas_table1 = nullptr;


}

void MainWindow::on_lineEdit_poisk_textChanged()//окрашивание вводимого в поиск значения
{
    QPalette pal=ui->lineEdit_poisk->palette();//создаем палитру
    QColor red;//создаем цвета
    QColor white;
    red.setRgb(227,38,54);//задаем цвета
    white.setRgb(0,0,0);
    bool fl;
    double num=ui->lineEdit_poisk->text().toDouble(&fl);
    if(fl&!((qIsNaN(num))||(qIsInf(num))))//проверка на вещественное
    {
        pal.setColor(QPalette::Text,white);//красим в белый
        ui->lineEdit_poisk->setPalette(pal);
    }
    else {
        pal.setColor(QPalette::Text,red);//ошибка - красим в красный
        ui->lineEdit_poisk->setPalette(pal);
    }
    
}


void MainWindow::on_pushButton_fill_clicked()//заполнение массива одним числом
{
    mnogo();
    ui->tableWidget_2->clearContents();
    ui->label_kolvo_ans->clear();
    ui->tableWidget_2->setRowCount(0);
    int row=ui->tableWidget->rowCount();
    bool fl;//флаг успешной конвертации ячейки
    double fillnum=ui->lineEdit_fill->text().toDouble(&fl);//считали и преобразовываем искомое число
    if(fl&&!((qIsNaN(fillnum))||(qIsInf(fillnum))))//если вещественное число
    {
        for (int i=0;i<row;i++)
        {
            if (ui->tableWidget->item(i,0)==nullptr)//пустая ячейка
            {
                QTableWidgetItem * ti; //создали указатель
                ti =  new QTableWidgetItem(); //выделяем память
                ui->tableWidget->setItem(i,0,ti); //помещаем ячейку в таблицу;
            }

            ui->tableWidget->item(i,0)->setText(QString::number(fillnum));//заполняем числом
        }
        on_lineEdit_fill_textChanged();
    }
    else
    {
        QMessageBox::information(this,"Ошибка","Массив можно заполнять только вещественными числами, реальными для счета");
        on_lineEdit_fill_textChanged();
    }
    delete[] mas_table1;
    mas_table1 = nullptr;
}

void MainWindow::on_pushButton_deletedub_clicked()//удаление дубликатов в массиве
{

    mnogo();
    int row=ui->tableWidget->rowCount();

    bool fl;//флаг успешной конвертации ячейки
    bool gl_fl=true;//фалг успешного создания массива
    mas_table1 = new double[row];

    for (int i=0;i<row;i++)//формирование массива
    {
        if (ui->tableWidget->item(i,0)==nullptr)//пустая ячейка
        {
            gl_fl=false;
            QTableWidgetItem * ti; //создали указатель
            ti =  new QTableWidgetItem(); //выделяем память
            ui->tableWidget->setItem(i,0,ti); //помещаем ячейку в таблицу;
        }
        else
        {
            mas_table1[i]=ui->tableWidget->item(i,0)->text().toDouble(&fl);//конвертируем
            if(fl&&!((qIsNaN(mas_table1[i]))||(qIsInf(mas_table1[i]))))//если сконвертировано
            {
                ui->tableWidget->item(i,0)->setBackground(Qt::white);//красим ячейку в белый
            }

            else {
                ui->tableWidget->item(i,0)->setBackgroundColor(Qt::red);//красим ячейку в красный
                gl_fl=false;
            }

        }
    }
    if(gl_fl)
    {
        if(sorted(mas_table1,row))
        {
            double *mas_help;
            mas_help = new double[row];
            int count=0;
            for(int i=0;i<row;i++)
            {
                if(i==0||abs(mas_table1[i]-mas_table1[i-1])>1e-10)
                {
                    mas_help[count++]=mas_table1[i];
                }
            }
            delete [] mas_table1;//удалили массив
            mas_table1=nullptr;

            ui->spinBox_row->setValue(count);//устанавливаем новое количство строк
            for(int i=0;i<count;i++)
            {
                ui->tableWidget->item(i,0)->setText(QString::number(mas_help[i]));//заполняем таблицу
            }
            delete [] mas_help;//удаляем вспомогательный
            mas_help=nullptr;
        }

        else{
            QMessageBox::information(this,"Ошибка","Массив неотсортирован. Сначала отсортируйте его",QMessageBox::Ok);
        }
    }
    else {
        QMessageBox::information(this,"Ошибка","В таблице содержатся ячейки с некорректными значениями",QMessageBox::Ok);
    }
    delete[] mas_table1;
    mas_table1 = nullptr;
}



void MainWindow::on_lineEdit_fill_textChanged()//изменение заполняемого значения и окрашивание
{
    QPalette pal=ui->lineEdit_poisk->palette();//создаем палитру
    QColor red;//создаем цвета
    QColor white;
    red.setRgb(227,38,54);//задаем цвета
    white.setRgb(0,0,0);
    bool fl;
    double num=ui->lineEdit_fill->text().toDouble(&fl);
    if(fl&!((qIsNaN(num))||(qIsInf(num))))//проверка на вещественное
    {
        pal.setColor(QPalette::Text,white);//красим в белый
        ui->lineEdit_fill->setPalette(pal);
    }
    else {
        pal.setColor(QPalette::Text,red);//ошибка - красим в красный
        ui->lineEdit_fill->setPalette(pal);
    }
}

void MainWindow::mnogo()//вывод предупреждения о длительности операции
{
    int row=ui->tableWidget->rowCount();
    if(row>=300000)
    {
        QMessageBox::information(this,"Предупреждение","При большом количестве строк в таблице, возможно долгое выполнение программы. \nНе волнуйтесь, ожидайте! \nВы можете уменьшить значение до 300000, программе станет легче.",QMessageBox::Ok);
    }
    delete[] mas_table1;
    mas_table1 = nullptr;
}
