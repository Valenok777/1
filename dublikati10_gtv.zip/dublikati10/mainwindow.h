#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMessageBox>
#include <math.h>
#define MAX_MAS_SIZE 1000000
#define MIN_MAS_SIZE 1
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_tableWidget_cellChanged(int row, int column);

    void on_spinBox_row_valueChanged(int arg1);


    void on_pushButton_clear_clicked();//очистка

    void on_pushButton_rand_clicked();//рнадомное заполнение

    void on_pushButton_min_clicked();//определение минимума и его вывод

    void on_pushButton_srednee_clicked();//определение среднего и его вывод

    void on_pushButton_max_clicked();//определение максимума и его вывод

    void quick_sort(double *mas_table1,int row);//быстрая сортировка

    void rascheska(int row);//расческа сортировка

    void buble(int row);// пузырьковая сортировка

    void gnom(int row);//гномья сортировка

    void monkey(int row);//обезьянья сортировка

    bool sorted(double *mas_table1,int row);//флаг отсортированности

    void err_str();//подсветка строки с ошибкой

    void on_pushButton_sort_clicked();//выполнение сортировки

    void on_pushButton_poisk_clicked();//поиск

    void on_lineEdit_poisk_textChanged();//изменение искомого значения и окрашивание

    void on_pushButton_fill_clicked();//заполнение массива одним числом

    void on_pushButton_deletedub_clicked();//удаление дубликатов в массиве

    void on_lineEdit_fill_textChanged();//изменение заполняемого значения и окрашивание
    
    void mnogo();//вывод предупреждения о длительности операции

private:
    Ui::MainWindow *ui;


    double *mas_table1;//массив
};

#endif // MAINWINDOW_H
